package com.ctl.it.qa.eon.tests;

import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import com.ctl.it.qa.staf.Environment;
import com.ctl.it.qa.staf.RallyTools;
import com.ctl.it.qa.staf.STAFEnvironment;
import com.ctl.it.qa.staf.Steps;
import com.ctl.it.qa.staf.TestEnvironment;
import com.ctl.it.qa.staf.SplunkLogger;
import cucumber.api.CucumberOptions;

@TestEnvironment(Environment.TEST4)
@RunWith(CucumberWithSerenity.class)
@CucumberOptions(

		plugin = { "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt", "usage:target/cucumber-usage.json",
				"junit:target/cucumber-results.xml", "html:target/cucumber-report/",
				"rerun:target/rerun-failed-scenarios/rerun.txt"},

		features = "src/test/resources/features/",

		monochrome = true,

		tags = { "@ColocationSanity" }

)

public class EonTestRunner {

	@BeforeClass
	public static void setEnvironment() {
		STAFEnvironment.registerEnvironment(EonTestRunner.class);
		Steps.initialize("EON-GC.xml");
		SplunkLogger.cukeTestSplunkBeforeClass();
		RallyTools.initiateRallyLogin();
	}

	@AfterClass
	public static void generateSplunkLog() {
		SplunkLogger.cukeTestSplunkAfterClass(EonTestRunner.class);
		RallyTools.closeRallyAPI();
	}

}