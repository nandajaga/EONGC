package com.ctl.it.qa.eon.tests.steps.user;

import net.thucydides.core.annotations.Steps;
import static org.hamcrest.MatcherAssert.assertThat;

import java.text.ParseException;

import com.ctl.it.qa.eon.tools.steps.user.EonUserSteps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserStepDefinition {

	 @Steps
	    EonUserSteps endUser;
	    
	    //Nanda
	    @Given("^I am in EON Login page$")
	    public void i_am_in_EON_Login_page() {
	    	endUser.is_in_EON_login_page();
	    }
	   
	    @When("^I login as a \"([^\"]*)\" user and switch back to 'ORDERS' Tab$")
	    public void i_login_as_a_user_and_switch_back_to_ORDERS_Tab(String userType) throws Exception {
	    	endUser.login_as_a_user_and_switch_back_to_ORDERS_Tab(userType);
	    	
	    }
	    
	    @And("^Switch to order window and select \"([^\"]*)\" and \"([^\"]*)\" and fill the mandatory fields and save$")
	    public void switch_to_order_window_and_select_and_and_fill_the_mandatory_fields_and_save(String SalesRegion, String BillingSystem) throws InterruptedException{
	    	endUser.Configure_initial_detailsTAB_info(SalesRegion, BillingSystem);
	    }
	    
	    
	    @And("^Switch to 'ITEM' Tab and select the \"([^\"]*)\" and type of \"([^\"]*)\"$")
	    public void switch_to_ITEM_Tab_and_select_the_and_type_of(String Product, String Action) throws Exception {
	    	endUser.switch_to_ITEM_Tab_and_select_the_Product_and_type_of_action(Product,Action);
	    }
	   
	    @And("^select \"([^\"]*)\" and required configuration and complete the check order tasks$")
	    public void select_and_required_configuration_and_complete_the_check_order_tasks(String SubProfile) throws Exception {
	    	endUser.select_the_required_configuration_and_complete_the_check_order_tasks(SubProfile);
	    	endUser.check_order_tasks_completition();
	    }
	    
	    @Then("^order status should move to \"([^\"]*)\"$")
	    public void order_status_should_move_to_something(String orderStatus) throws InterruptedException {
	       assertThat("Actual Order Status is not same as expected status'"+ orderStatus + "'",
	    	endUser.order_status_should_move_to_In_Service(orderStatus));
	    }
	    
	    @Then("^Switch to 'ITEM' Tab and select the 'Access Circuit' and type of action as 'ADD'$")
	    public void switch_to_ITEM_Tab_and_select_the_Access_Circuit_and_type_of_action_as_ADD() throws Exception {
	    	endUser.add_Access_circuit();
	    }


	    @Then("^select SubProfile 'Access Circuit' and required configuration and complete the check order tasks$")
	    public void select_SubProfile_Access_Circuit_and_required_configuration_and_complete_the_check_order_tasks() throws Exception {
	    	endUser.configure_Access_circuit();
	    	endUser.Check_Order_Task_completition();
	    	endUser.fetch_AccessCircuit_details();

	    }

	    @When("^Switch to 'ITEM' Tab and select the \"([^\"]*)\" and type of \"([^\"]*)\" for 'Dedicated Internet'$")
	    public void switch_to_ITEM_Tab_and_select_the_and_type_of_for_Dedicated_Internet(String Product, String Action) throws Exception {
	    	endUser.add_product_with_AccessCircuitID(Product,Action);
	    }
	    
	    @When("^Switch to 'ITEM' Tab and select the \"([^\"]*)\" and type of \"([^\"]*)\" for 'IP VRP'$")
	    public void switch_to_ITEM_Tab_and_select_the_and_type_of_for_IP_VRP(String Product, String Action) throws Exception {
	    	endUser.add_product_with_AccessCircuitID(Product,Action);
	    }
	    
	    @When("^select \"([^\"]*)\" and required configuration and complete the check order tasks for Dedicated Internet$")
	    public void select_and_required_configuration_and_complete_the_check_order_tasks_for_Dedicated_Internet(String SubProfile) throws Exception {
	    	endUser.select_the_subProfile(SubProfile);
	    	endUser.select_the_configuaration_for_dedicated_Internet();
	    	endUser.Check_Order_Task_completition();
	    }
	    
	    @When("^select \"([^\"]*)\" and required configuration and complete the check order tasks for \"([^\"]*)\"$")
	    public void select_and_required_configuration_and_complete_the_check_order_tasks_for(String SubProfile,String Product) throws Exception {
	    	endUser.select_the_subProfile(SubProfile);
	    	endUser.select_the_configuaration_for_IP_VRP();
	    	endUser.Check_Order_Task_completion_for_products(Product);
	    }
	    
	    @Then("^I send order details in an email$")
		public void i_send_order_details_in_an_email() throws Throwable {
			endUser.SendEmailhavingOrderDetails();

		} 
	    
	    @Then("^go to item details page select \"([^\"]*)\" and verify the'LEXM WO'field$")
	    public void go_to_item_details_page_select_and_verify_the_LEXM_WO_field(String subProfile) {
	    	endUser.select_the_subProfile(subProfile);
	    	endUser.verify_LEXMWO_field();
	    	
	    }
	    
		@And("^Switch to 'ITEM' Tab and select the Co-location/Mid-span Meet as \"([^\"]*)\" and type of \"([^\"]*)\"$")
		public void switch_to_ITEM_Tab_and_select_the_Co_location_Mid_span_Meet_as_and_type_of(String Product, String Action) throws Exception {
		endUser.switch_to_ITEM_Tab_and_select_the_Product_and_type_of_action(Product,Action);
		}

		@And("^select Co-location as\"([^\"]*)\" and required configuration and complete the check order tasks$")
		public void select_Co_location_as_and_required_configuration_and_complete_the_check_order_tasks(String SubProfile) throws Exception {
		endUser.select_the_required_Colocation_configuration_and_complete_the_check_order_tasks(SubProfile);
		endUser.check_order_tasks_completition_for_colocation();
		}	    
		
		
		@Given("^As an \"([^\"]*)\" On IPGateway/RVA site$")
		public void as_an_On_IPGateway_RVA_site(String userType) throws Exception {
			endUser.is_in_EON_login_page();
			endUser.login_as_a_user_and_switch_back_to_ORDERS_Tab(userType);
			endUser.Configure_initial_detailsTAB_info();
			endUser.switch_to_ITEM_Tab_and_select_the_IPGateWayRVASite_and_type_of_action();
		}


		@When("^when SAB box is checked$")
		public void when_SAB_box_is_checked() throws Exception {
			
			endUser.select_the_configuaration_for_IPGateWayRVASite_AC1();
		    
		}

		@Then("^validate that A new drop down with the label Access Type is added below the \"SAB check box$")
		public void validate_that_A_new_drop_down_with_the_label_Access_Type_is_added_below_the_SAB_check_box() throws Exception {
			endUser.validate_that_A_new_drop_down_with_the_label_Access_Type_is_added_below_the_SAB_check_box();
			
		}
		
		@Then("^validate that LOV for Access Type is  - Customer Provided Access, Broadband and Cellular$")
		public void validate_that_lov_for_Access_Type_is_Customer_Provided_Access_Broadband_and_Cellular() throws Exception {
			endUser.validate_that_lov_for_Access_Type_is_Customer_Provided_Access_Broadband_and_Cellular();
			
		}
		
		@Then("^validate that If user selects Broadband for Access Type, display a new mandatory text box with the label Access SWIFT ID$")
		public void validate_that_If_user_selects_Broadband_for_Access_Type_display_a_new_mandatory_text_box_with_the_label_Access_SWIFT_ID() throws Exception {
			endUser.validate_that_If_user_selects_Broadband_for_Access_Type_display_a_new_mandatory_text_box_with_the_label_Access_SWIFT_ID();
		}
		
		@Then("^validate that If user selects Cellular for Access Type, display a new mandatory text box with the label Access SWIFT ID$")
		public void validate_that_If_user_selects_Cellular_for_Access_Type_display_a_new_mandatory_text_box_with_the_label_Access_SWIFT_ID() throws Exception {
			endUser.validate_that_If_user_selects_Cellular_for_Access_Type_display_a_new_mandatory_text_box_with_the_label_Access_SWIFT_ID();
		}
		
		@Then("^For Access Type equal to Customer Provided Access do not display Access SWIFT ID$")
		public void for_Access_Type_equal_to_Customer_Provided_Access_do_not_display_Access_SWIFT_ID() throws Exception {
			endUser.for_Access_Type_equal_to_Customer_Provided_Access_do_not_display_Access_SWIFT_ID();
		}

		@Then("^Validate that with Cellualar as Access Type, Access SWIFT ID text box to accept only the numbers starting with thirty three with total nine digit number$")
		public void validate_that_with_Cellular_as_Access_type_Access_SWIFT_ID_text_box_to_accept_only_the_numbers_starting_with_thirty_three_with_total_nine_digit_number() throws Exception {
			endUser.validate_that_with_Cellular_as_Access_type_Access_SWIFT_ID_text_box_to_accept_only_the_numbers_starting_with_thirty_three_with_total_nine_digit_number();
		}
		
		@Then("^Validate that with Broadband as Access Type, Access SWIFT ID text box to accept only the numbers starting with thirty three with total nine digit number$")
		public void validate_that_with_Broadband_as_Access_type_Access_SWIFT_ID_text_box_to_accept_only_the_numbers_starting_with_thirty_three_with_total_nine_digit_number() throws Exception {
			endUser.validate_that_with_Broadband_as_Access_type_Access_SWIFT_ID_text_box_to_accept_only_the_numbers_starting_with_thirty_three_with_total_nine_digit_number();
		}

		@Then("^Validate that with Broadband as Access Type, Validate Error message if we dont start number with thirty three for Access Swift ID$")
		public void validate_that_with_Broadband_as_Access_Type_Validate_Error_message_if_we_dont_start_number_with_thirty_three_for_Access_Swift_ID() throws Exception {
			endUser.validate_that_with_Broadband_as_Access_Type_Validate_Error_message_if_we_dont_start_number_with_thirty_three_for_Access_Swift_ID();
		}
		
		@Then("^Validate that with Cellular as Access Type, Validate Error message if we dont start number with thirty three for Access Swift ID$")
		public void validate_that_with_Cellular_as_Access_Type_Validate_Error_message_if_we_dont_start_number_with_thirty_three_for_Access_Swift_ID() throws Exception {
			endUser.validate_that_with_Cellular_as_Access_Type_Validate_Error_message_if_we_dont_start_number_with_thirty_three_for_Access_Swift_ID();
		}

	    @Given("^As an \"([^\"]*)\"$")
	    public void as_an(String userType) throws Exception {
			endUser.is_in_EON_login_page();
			endUser.login_as_a_user_and_switch_back_to_ORDERS_Tab(userType);
			endUser.Configure_initial_detailsTAB_info();
			
	    }

	    @When("^IPGateway/RVA site is created$")
	    public void ipgateway_RVA_site_is_created() throws Exception {
	    	endUser.switch_to_ITEM_Tab_and_select_the_IPGateWayRVASite_and_type_of_action();
	    	endUser.select_the_configuaration_for_IPGateWayRVASite_US304733();
	    }

	    @Then("^Validate that under IPSEC section a new text box is added with the label 'CPE Public IP Gateway Address'$")
	    public void validate_that_under_IPSEC_section_a_new_text_box_is_added_with_the_label_CPE_Public_IP_Gateway_Address() throws Exception {
	    	endUser.validate_that_under_IPSEC_section_a_new_text_box_is_added_with_the_label_CPE_Public_IP_Gateway_Address();
	    }

	    @Then("^Validate 'CPE Public IP Gateway Address' is optional$")
	    public void validate_CPE_Public_IP_Gateway_Address_is_optional() throws Exception {
	    	endUser.validate_CPE_Public_IP_Gateway_Address_is_optional();	        
	    }

	    @Then("^Validate 'CPE Public IP Gateway Address' is optional to accept only the valid IP addresses$")
	    public void validate_cpe_Public_IP_Gateway_Address_is_optional_to_accept_only_the_valid_IP_addresses() throws Exception {
	    	endUser.validate_cpe_Public_IP_Gateway_Address_is_optional_to_accept_only_the_valid_IP_addresses();
	    }

	    @Then("^If invalid format value is entered for 'CPE Public IP Gateway Address' then validate error message as: 'Invalid IP Address: CIDR Format XXX\\.XXX\\.XXX\\.XXX/YY Required'$")
	    public void if_invalid_format_value_is_entered_for_CPE_Public_IP_Gateway_Address_then_validate_error_message_as_Invalid_IP_Address_CIDR_Format_XXX_XXX_XXX_XXX_YY_Required() throws Exception {
	        endUser.if_invalid_format_value_is_entered_for_CPE_Public_IP_Gateway_Address_then_validate_error_message_as_Invalid_Ip_Address_CIDR_Format_XXX_XXX_XXX_XXX_YY_Required();
	    }		
		
	
	    @Then("^Switch to 'CONTACTS'TAB and verify 'Hours of Availability' is available and update \"([^\"]*)\" result$")
	    public void switch_to_CONTACTS_TAB_and_verify_Hours_of_Availability_is_available_and_update_result(String tcid) {
	    	endUser.contacts_validation_Hours_of_Availability(tcid);
	    }
	    
	    @Then("^select \"([^\"]*)\" and valdiate \"([^\"]*)\" is removed from EON vendors list displayed in A/Z access loop detail$")
	    public void select_something_and_valdiate_something_is_removed_from_eon_vendors_list_displayed_in_az_access_loop_detail(String subprofile, String strArg1) throws Throwable {
	        endUser.validate_ITS_TELECOMUNICAÇÕES_LTDA_removed_from_localLoop(subprofile);
	    }
	    
	    @And("^select required configuration and save$")
	    public void select_required_configuration_and_save() throws Throwable {
	    	endUser.configuartion_before_save_IPGateway();
	    }
	    
	    @Then("^select \"([^\"]*)\" value and validate corresponding \"([^\"]*)\" value is available in Device dropdown and update\"([^\"]*)\" result$")
	    public void select_something_value_and_validate_corresponding_something_value_is_available_in_device_dropdown_and_updatesomething_result(String nsdlocation, String device, String tcid) throws Throwable {
	      endUser.select_NSDLocation_and_Device_Values(nsdlocation,device);
	    }

	    @And("^select \"([^\"]*)\" for EtherExtend and fill the required configuration and complete the check order tasks for \"([^\"]*)\"$")
	    public void select_something_for_etherextend_and_fill_the_required_configuration_and_complete_the_check_order_tasks_for_something(String SubProfile, String Product) throws Throwable {
			endUser.select_the_subProfile(SubProfile);
			endUser.select_the_configuaration_template_for_EtherExtend();
	    	endUser.Check_Order_Task_completion_for_products(Product);
	    }
	    
	    @When("^I click on \"([^\"]*)\" in login page$")
	    public void i_click_on_in_login_page(String link) {
	    	endUser.Active_Directory_Domain_Password_Reset(link);
	    }


	    @Then("^I need EON to take me to the following password reset screen \"([^\"]*)\"$")
	    public void i_need_EON_to_take_me_to_the_following_password_reset_screen(String pwdurl) {
	    	endUser.password_reset_page(pwdurl);
	    }

	    @Then("^assert that user is in PWD reset page$")
	    public void assert_that_user_is_in_PWD_reset_page() {
	    	endUser.validate_user_in_PWD_Reset_page();
	    }

	    
	    @And("^select \"([^\"]*)\" and validate the values for 'Cloud Connect Product'$")
	    public void select_something_and_validate_the_values_for_cloud_connect_product(String SubProfile) throws Throwable {
	    	endUser.select_the_subProfile(SubProfile);
	    	endUser.select_the_configuaration_and_validate_Cloud_connect_Values_IPVRP();
	    }
	    
	    @And("^select \"([^\"]*)\" and required configuration and complete the check order task and validate AutoCCD calculator$")
	    public void select_something_and_required_configuration_and_complete_the_check_order_task_and_validate_autoccd_calculator(String SubProfile) throws Throwable {
	    	endUser.select_the_required_configuration_and_complete_the_check_order_tasks(SubProfile);
	    	endUser.complete_only_checkOrder_task_and_verify_AutoCCDCalculator();
	    }
	    
	    @And("^select \"([^\"]*)\" for EtherExtend and fill the required configuration, choose invalid circuit speed and validate error message in History TAB$")
	    public void select_something_for_etherextend_and_fill_the_required_configuration_choose_invalid_circuit_speed_and_validate_error_message_in_history_tab(String SubProfile) throws Throwable {
			endUser.select_the_subProfile(SubProfile);
			endUser.select_the_configuaration_template_for_EtherExtend_Invalid_circuitSpeed();
			endUser.validate_error_message_in_HistoryTAB();
	    }
	    
	    @When("^I login as a \"([^\"]*)\" user and switch back to 'ADMIN' Tab$")
	    public void i_login_as_a_user_and_switch_back_to_ADMIN_Tab(String userType) {
	    	endUser.login_as_a_user_and_switch_back_to_ORDERS_Tab(userType);
	    	endUser.goto_utility_page();
	    }
	    
	    @Then("^I Validate the utilities under \"([^\"]*)\" when no file is selected display \"([^\"]*)\" error message$")
	    public void i_validate_the_utilities_under_something_when_no_file_is_selected_display_something_error_message(String bulkrecordupdates, String popupmsg) throws Throwable {
	    	endUser.verify_Bulk_record_update_utilities(bulkrecordupdates,popupmsg);

	    }

	    @Then("^I validate the 'Utility List' is added to 'Bulk Upload Orders' to go back to Utilities list$")
	    public void i_validate_the_Utility_List_is_added_to_Bulk_Upload_Orders_to_go_back_to_Utilities_list() {
	    	endUser.verify_utility_list_added_to_BulkUploadOrder();
	    }
	    
	    @Then("^I Validate the utilities under 'Bulk Record Updates' when no file is selected display \"([^\"]*)\" error message$")
	    public void i_Validate_the_utilities_under_Bulk_Record_Updates_when_no_file_is_selected_display_error_message(String popupmsg) {
	    }
	    
	    @Then("^I validate the 'Utility List' is added to utilities present under 'Legacy/Non usable Utilities'$")
	    public void i_validate_the_Utility_List_is_added_to_utilities_present_under_Legacy_Non_usable_Utilities() {
	    	endUser.verify_utility_is_added_to_LegacyNon_usable_Utilities();
	    }
	    
	    @When("^select \"([^\"]*)\" and required configuration and save the Item$")
	    public void select_and_required_configuration_and_save_the_Item(String SubProfile) throws InterruptedException {
	        // Write code here that turns the phrase above into concrete actions
			if(SubProfile.equals("UNI")) {
				endUser.select_the_subProfile(SubProfile);
			    endUser.select_the_configuaration_template_for_EtherExtend();
			} else if(SubProfile.equals("Co-location")) {
				endUser.select_the_required_Colocation_configuration_and_complete_the_check_order_tasks(SubProfile);
			} else if(SubProfile.equals("IPL")||SubProfile.equals("WDM/Lambda")) {
				endUser.select_the_required_configuration_and_complete_the_check_order_tasks(SubProfile);
			}
	    }

	    @Then("^switch to 'CFA TAB' and select 'FOC Received Date, DLR Received Date and Loop Accept Date' on A and Z side and save$")
	    public void switch_to_CFA_TAB_and_select_FOC_Received_Date_DLR_Received_Date_and_Loop_Accept_Date_on_A_and_Z_side_and_save() throws ParseException {
	    	endUser.CFA_TAB_select_FOC_DLR_Loop_Date();
	    }

	    @Then("^Validate the 'REST API' response containing the dates selected on UI$")
	    public void validate_the_REST_API_response_containing_the_dates_selected_on_UI() { 
	    	endUser.validate_REST_response();
	    }
	    
	    @Then("^using 'REST API PUT' set the 'TRTS date'for a given OrderItem$")
	    public void using_rest_api_put_set_the_trts_datefor_a_given_orderitem() throws ParseException{
	    	endUser.call_RESTAPI_PUT_to_update_TRTSDate();
	    }

	    @And("^validate the TRTS date is updated in Item Details page and also in REMARKS Tab$")
	    public void validate_the_trts_date_is_updated_in_itemdetails_page_and_also_in_remarks_tab() {
	    	endUser.Validate_TRTS_date_updated_by_REST_API();
	    }
	    
}
