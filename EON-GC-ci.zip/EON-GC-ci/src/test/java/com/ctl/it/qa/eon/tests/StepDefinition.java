package com.ctl.it.qa.eon.tests;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.ctl.it.qa.eon.tools.steps.user.EonUserSteps;
import com.ctl.it.qa.staf.Page;
import com.ctl.it.qa.staf.RallyTools;
import com.ctl.it.qa.staf.SplunkLogger;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;


public class StepDefinition {
	
	@Steps
	EonUserSteps EonUserSteps;

	
	@Before
	public void beforeEveryScenario(Scenario scenario) throws IOException {

		SplunkLogger.stepDefinitionSplunkBefore(StepDefinition.class,scenario);		
		
	}
	
	@After
	public void afterEveryScenario(Scenario scenario) {
		SplunkLogger.stepDefinitionSplunkAfter(StepDefinition.class,scenario);
		com.ctl.it.qa.staf.Steps.isInitialized = false;
		Page.isInitialized = false;
		scenario.write("Data used for this test case:" + "\r\n");
		printData(scenario);
		
		/*try {
			EonUserSteps.captureTestResult(scenario);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			EonUserSteps.getDriver().quit();
		}*/
		
		if (scenario.isFailed()) {			
			File src= ((TakesScreenshot)EonUserSteps.getDriver()).getScreenshotAs(OutputType.FILE);
			try {
				FileUtils.copyFile(src, new File(System.getProperty("user.dir") +"\\target\\EON-GC_Error-Screenshot.png"));
				scenario.embed(((TakesScreenshot)EonUserSteps.getDriver()).getScreenshotAs(OutputType.BYTES), "image/png");
			}

			catch (IOException e)
			{
				System.out.println(e.getMessage());

			}
			


			SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

			Date dateobj = new Date();
			
			sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

			System.out.println(sdobj.format(dateobj));

			System.out.println("Sending Order Details in email...");

			InetAddress ip;

			String hostname = null;

			String hostIPAddress = null;

			try {

				ip = InetAddress.getLocalHost();

				hostname = ip.getHostName();

				hostIPAddress =ip.getHostAddress();


			} catch (UnknownHostException e) {

				e.printStackTrace();

			}

			java.util.Properties props = new java.util.Properties();

			props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

			Session session = Session.getDefaultInstance(props, null);

			String from = "nnanda.kumar@centurylink.com";

			String subject = "EON-GC 2019-08 (AUG) SMR_Automation Sanity is Failed in QA4_" + sdobj.format(dateobj);
			
			Message msg = new MimeMessage(session);

			try {       

				msg.setFrom(new InternetAddress(from));

			
				msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@centurylink.com"));

			//	msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("Praveen.K.Chinni@centurylink.com,Praveen_L3_Test@CenturyLink.com"));

				msg.setSubject(subject);

				MimeMultipart multipart = new MimeMultipart("related");

				BodyPart msgBodyPart = new MimeBodyPart();

				String htmlText = "<html>\n" +

	                            "<Head></head>\n"+

	                            "<body>\n"+

	                            "<pr>Hi All,</pr>\n"+

	                            "<br><br>\n"+

	                            "<pr>EON-GC 2019-04 (APR) SMR_Automation Sanity is Failed in QA4. Please find below the snapshot depicting the error,</pr>\n"+

	                            "<br><br>\n"+

	                            "<b><u>Validation Error Snapshot Details:</u></b>\n"+

	                            "<br><br>\n"+

	                            "<table border= 2 cellpadding= 2 cellspacing= 0>\n"+

	                            "<tr><td colspan = 2>\n"+

	                            "<img  align =center src=\"cid:ValidationErrorScreenshotDetails\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

	                            "</td></tr>\n"+                                 

	                            "<tr><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></tr>\n"+

	                            "</table>\n"+

	                            "<br>\n"+

	                            "<br>\n"+

	                            "<br>\n"+

	                            "<br>\n"+                                

	                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

	                            "<br>\n"+

	                            "<pr>***serenity-cucumber-archetype using Selenium 3.10.0, JUnit and Cucumber-JVM with CTL-STAF as dependency***</p>\n"+

	                            "<br>\n"+

	                            //"<pr>Note*: This sanity mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients. Screenshot doesnot display in case if application URL only is not launched </p>\n"+

	                            "<br>\n"+

	                            "<br>\n"+

	                            "<br>\n"+

								"<br>\n"+

	                            "<pr>Regards,</pr>\n"+

	                            "<br>\n"+

	                            "<pr>Nanda Kumar</pr>\n"+

	                            "</body>\n"+

	                            "</html>";                         

				msgBodyPart.setContent(htmlText, "text/html");
				multipart.addBodyPart(msgBodyPart);

				Map<String, String> mapinlineImages = new HashMap<String, String>();
				mapinlineImages.put("ValidationErrorScreenshotDetails", System.getProperty("user.dir") +"\\target\\EON-GC_Error-Screenshot.png");

				if (mapinlineImages != null && mapinlineImages.size() > 0) {
					Set<String> setImageID = mapinlineImages.keySet();

					for (String contentId : setImageID) {
						MimeBodyPart imagePart = new MimeBodyPart();
						imagePart.setHeader("Content-ID", "<" + contentId + ">");
						imagePart.setDisposition(MimeBodyPart.INLINE);

						String imageFilePath = mapinlineImages.get(contentId);
						try {
							imagePart.attachFile(imageFilePath);
						} catch (IOException ex) {
							ex.printStackTrace();
						}

						multipart.addBodyPart(imagePart);
					}
				}

				msg.setContent(multipart);
				Transport.send(msg);

				System.out.println("Sent email successfully....");

			} catch (MessagingException e) {
				throw new RuntimeException(e);
			}						
		
	}
		
		try
        {
            System.out.println("Checking for Driver existense, if it exists closing it.");
        }
		
		
        finally
        
        {
        	RallyTools.captureResultforCaaC(scenario);
        	
            if (EonUserSteps.getDriver() != null)
            {
            	EonUserSteps.getDriver().close();
            	EonUserSteps.getDriver().quit();
            	System.out.println("closed browsers and quit browser's driver.");

            }
        }
		
		
	}
	
    private void printData(Scenario scenario) {
    	

        if (Serenity.sessionVariableCalled("product_name") != null) {
                        scenario.write("Product Name : " + Serenity.sessionVariableCalled("product_name").toString());
        }
        
        if (Serenity.sessionVariableCalled("request_id") != null) {
                        scenario.write("Request ID : " + Serenity.sessionVariableCalled("request_id").toString());
        }
        
    
        

}
}
