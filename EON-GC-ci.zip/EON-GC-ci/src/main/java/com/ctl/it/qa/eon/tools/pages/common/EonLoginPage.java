package com.ctl.it.qa.eon.tools.pages.common;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

import com.ctl.it.qa.eon.tools.pages.EonPage;
import com.ctl.it.qa.staf.xml.reader.IntDataContainer;

public class EonLoginPage extends EonPage {

	@FindBy(name = "username")
	public WebElementFacade tbx_username;

	@FindBy(name = "password")
	public WebElementFacade tbx_password;

	@FindBy(xpath = "//input[@value='Login']")
	public WebElementFacade btn_log_In_To_EON;
	
	@FindBy(xpath="(//a[text()='Active Directory Domain Password Reset'])[1]")
	public WebElementFacade lnk_PWDReset;
	
	@FindBy(xpath="(//a[text()='Active Directory Domain Password Reset'])[2]")
	public WebElementFacade lnk_PWDReset1;
	
	@FindBy(xpath="//h2[text()='AMS domain password reset']")
	public WebElementFacade lbl_AMStext;
	
	

	@Override
	public WebElementFacade getUniqueElementInPage() {
		return btn_log_In_To_EON;
	}

	public void enterCredentials(String userType) {
		IntDataContainer dataContainer = envData.getContainer(
				this.getClass().getSimpleName()).getContainer(userType);
		tbx_username.type(dataContainer.getFieldValue("tbx_username"));
		tbx_password.type(dataContainer.getFieldValue("tbx_password"));
	}

	public void clickLogin() {
		btn_log_In_To_EON.click();
	}
}