package com.ctl.it.qa.eon.tools.steps;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.ctl.it.qa.eon.tools.pages.common.EonDetailsPage;
import com.ctl.it.qa.eon.tools.pages.common.EonHomePage;
import com.ctl.it.qa.eon.tools.pages.common.EonLoginPage;
import com.ctl.it.qa.staf.Page;
import com.ctl.it.qa.staf.Steps;
import com.ctl.it.qa.staf.xml.reader.IntDataContainer;

@SuppressWarnings("serial")
public abstract class EonSteps extends Steps {
	
	EonLoginPage EonLoginPage;
    EonHomePage EonHomePage;
    EonDetailsPage EonDetailsPage;
    
    public IntDataContainer get_data_for_page(Page page) {
		commonData.getContainer(page.getClass().getSimpleName())
				.setActualValuesForAllContainers();
		return commonData.getContainer(page.getClass().getSimpleName());
	}
	
	public IntDataContainer get_container_from_xml(String... containers){
		IntDataContainer actualContainer= commonData;
		for(int i=0;i<containers.length;i++){
			actualContainer=actualContainer.getContainer(containers[i]);
		}
		actualContainer.setActualValuesForAllContainers();
		return actualContainer;
	}
	
    
	 public void highLighElement(WebElement element){
	 JavascriptExecutor js = (JavascriptExecutor) getDriver();
	 js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
	 }
	
	
}
