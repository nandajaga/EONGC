package com.ctl.it.qa.eon.tools.pages;

import com.ctl.it.qa.staf.Page;

public abstract class EonPage extends Page {

}
