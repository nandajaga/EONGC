package com.ctl.it.qa.eon.tools.steps.user;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.imageio.ImageIO;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.Matchers.*;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;


import com.ctl.it.qa.eon.tools.pages.common.EonDIAItemDetailsPage;
import com.ctl.it.qa.eon.tools.pages.common.EonDetailsPage;
import com.ctl.it.qa.eon.tools.pages.common.EonHomePage;
import com.ctl.it.qa.eon.tools.pages.common.EonIPGateWayRVASiteItemDetailsPage;
import com.ctl.it.qa.eon.tools.pages.common.EonIPVRPItemDetailsPage;
import com.ctl.it.qa.eon.tools.pages.common.EonItemDetailsPage;
import com.ctl.it.qa.eon.tools.pages.common.EonLoginPage;
import com.ctl.it.qa.eon.tools.steps.EonSteps;
import com.ctl.it.qa.staf.Environment;
import com.ctl.it.qa.staf.xml.reader.IntDataContainer;
import net.thucydides.core.annotations.Step;

@SuppressWarnings("serial")
public class EonUserSteps extends EonSteps {

	EonLoginPage EonLoginPage;
	EonHomePage EonHomePage;
	EonDetailsPage EonDetailsPage;
	EonItemDetailsPage EonItemDetailsPage;
	EonDIAItemDetailsPage EonDIAItemDetailsPage;
	EonIPVRPItemDetailsPage EonIPVRPItemDetailsPage;
	EonIPGateWayRVASiteItemDetailsPage EonIPGateWayRVASiteItemDetailsPage;
	public String ItemTAB;
	public String actualStatus;
	public static String Order_Item;
	public String CircuitID;
	public String productSelected;
	public String AccessCircuitID;
	public String OrderItemForRest;
	Map<String,String> datesonUI;
	public String TRTSDate[];
	

	@Step
	public void is_in_EON_login_page() {
		EonLoginPage.openAt(envData.getFieldValue("url"));
		EonLoginPage.maximize();
		waitABit(10000);
		EonLoginPage.shouldExist(EonLoginPage);
	}


	@Step
	public void login_as_a_user_and_switch_back_to_ORDERS_Tab(String userType) {
		// TODO Auto-generated method stub
		EonLoginPage.enterCredentials(userType);
		EonLoginPage.clickLogin();

	}

	@Step
	public void Configure_initial_detailsTAB_info(String SalesRegion, String BillingSystem)
			throws InterruptedException {
		System.out.println("from cucumber file: " + BillingSystem);
		waitABit(2000);
		EonDetailsPage.Windowhandle("Home");
		waitABit(2000);
		System.out.println("control retun back to User steps");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		System.out.println("Switched to TAB pane");
		EonDetailsPage.lbl_ordersTAB.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.btn_NEW.click();
		System.out.println("Switched to Entry pane and clicked on NEW");
		EonDetailsPage.Windowhandle("Order");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		
		IntDataContainer dat1 = get_data_for_page(EonDetailsPage).getContainer("EONOrderDetailsPageAddPrimaryContacts");
		fillFields(EonDetailsPage, dat1.getMandatoryFieldsFromAllContainers());
		waitABit(15000);
		System.out.println("waited 15 seconds");
		
		EonDetailsPage.ddl_salesRegion.selectByVisibleText(SalesRegion);
		System.out.println(EonDetailsPage.ddl_salesRegion.getSelectedValue());
		assertTrue(EonDetailsPage.ddl_salesRegion.getSelectedVisibleTextValue().contains(SalesRegion));
		waitABit(3000);
		EonDetailsPage.ddl_BillingSystem.selectByVisibleText(BillingSystem);
		System.out.println(EonDetailsPage.ddl_BillingSystem.getSelectedValue());
		assertTrue(EonDetailsPage.ddl_BillingSystem.getSelectedVisibleTextValue().contains(BillingSystem));
		waitABit(1000);
		EonDetailsPage.tbx_receivedDate.sendKeys(date1);
		EonDetailsPage.tbx_signedDate.sendKeys(date1);

		EonDetailsPage.tbx_gcodContactName.sendKeys("Naresh");
		waitABit(2000);
		List<WebElement> gcodContactName = getDriver()
				.findElements(By.xpath("//table[contains(@id, 'main:j_id199:')]//td"));
		fn_auotslectText(gcodContactName, "Naresh");

		EonDetailsPage.tbx_supportName.sendKeys("N Nanda Kumar");
		waitABit(2000);
		List<WebElement> SalesSupportContact = getDriver()
				.findElements(By.xpath("//table[contains(@id, 'main:j_id235:')]//td"));
		fn_auotslectText(SalesSupportContact, "Nanda");

		waitABit(2000);
		EonDetailsPage.tbx_repName.sendKeys("N Nanda Kumar");
		waitABit(2000);
		List<WebElement> SalesRepContact = getDriver()
				.findElements(By.xpath("//table[contains(@id, 'main:j_id226:')]//td"));
		fn_auotslectText(SalesRepContact, "Nanda");
		waitABit(2000);
		IntDataContainer dat = get_data_for_page(EonDetailsPage).getContainer("EONOrderDetailsPage");
		fillFields(EonDetailsPage, dat.getMandatoryFieldsFromAllContainers());
				
	    Thread.sleep(10000);
	    System.out.println("waited 10 seconds to click Save button");
	    
	    Actions saveButton = new Actions(getDriver());
	    saveButton.moveToElement(getDriver().findElement(By.name("main:savebutton"))).click().build().perform();
	        
		System.out.println("Order is saved successfully");
		
		waitABit(10000);
		
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		Thread.sleep(2000);
		EonDetailsPage.getDriver().switchTo().frame("header_pane");
		System.out.println("Order#:"+ EonDetailsPage.lbl_OrderNumber1.getText());
		EonDetailsPage.getDriver().switchTo().defaultContent();
	
	}

	@Step
	public void switch_to_ITEM_Tab_and_select_the_Product_and_type_of_action(String Product, String Action) {
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		System.out.println("Switched to tab pane");
		
/*		if(EonDetailsPage.lbl_ItemsTab.isCurrentlyEnabled()) {
			
			System.out.println("Items tab is enabled");
			EonDetailsPage.lbl_ItemsTab.click();
		}
			
			else
			{
				System.out.println("Items tab is not enabled");
				EonDetailsPage.getDriver().switchTo().defaultContent();
				EonDetailsPage.getDriver().switchTo().frame("workspacePane");
				EonDetailsPage.getDriver().switchTo().frame("entry_pane");
			    Actions saveButton = new Actions(getDriver());
			    saveButton.moveToElement(getDriver().findElement(By.name("main:savebutton"))).click().build().perform();
				EonDetailsPage.getDriver().switchTo().defaultContent();
				EonDetailsPage.getDriver().switchTo().frame("workspacePane");
				EonDetailsPage.getDriver().switchTo().frame("tab_pane");
				EonDetailsPage.lbl_ItemsTab.click();
			}*/
	
		EonDetailsPage.lbl_ItemsTab.click();
		System.out.println("Clicked Items tab");
		waitABit(5000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		System.out.println("Switched to Entry pane");
		waitABit(2000);	
		EonDetailsPage.ddl_Product.selectByVisibleText(Product);
		productSelected = EonDetailsPage.ddl_Product.getSelectedVisibleTextValue();
		assertTrue(productSelected.contains(Product));
		EonDetailsPage.ddl_action.selectByVisibleText(Action);
		waitABit(2000);
		EonDetailsPage.btn_productAdd.click();

	}

	@Step
	public void select_the_required_configuration_and_complete_the_check_order_tasks(String SubProfile) {
		ItemTAB = getDriver().getWindowHandle();
		waitABit(1000);
		EonDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.ddl_SubProfile.selectByVisibleText(SubProfile);
		assertTrue(EonDetailsPage.ddl_SubProfile.getSelectedVisibleTextValue().contains(SubProfile));
		EonDetailsPage.tbx_WantDate.sendKeys(date1);
		EonDetailsPage.tbx_IntervalDate.sendKeys(date1);		
		IntDataContainer dat = get_data_for_page(EonItemDetailsPage).getContainer("EONItemPipelineConfigurationDetails");
		fillFields(EonItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
		waitABit(3000);

	}
	
	@Step
	public void select_the_required_Colocation_configuration_and_complete_the_check_order_tasks(String SubProfile) {
		waitABit(5000);
		ItemTAB = getDriver().getWindowHandle();
		waitABit(3000);
		EonDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		System.out.println("Switched to entry_pane");
		waitABit(3000);				
		EonDetailsPage.ddl_SubProfile.selectByVisibleText(SubProfile);
		assertTrue(EonDetailsPage.ddl_SubProfile.getSelectedVisibleTextValue().contains(SubProfile));
		EonDetailsPage.tbx_WantDate.sendKeys(date1);
		EonDetailsPage.tbx_IntervalDate.sendKeys(date1);		
		IntDataContainer dat = get_data_for_page(EonItemDetailsPage).getContainer("EONItemColocationConfigurationDetails");
		fillFields(EonItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
		waitABit(8000);

	}	

	
	@Step
	public void check_order_tasks_completition() {
		System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		EonDetailsPage.cbx_CompleteOnClickAdmin.click();
		waitABit(2000);
		EonDetailsPage.btn_StartInHistory.click();
		waitABit(3000);
		EonDetailsPage.btn_RefreshInHistory.click();
		waitABit(3000);
		
		switch (productSelected) {
		
		case "WDM/Lambda":
			String[] wavelength = { "Check Order", "Setup Billing", "Notify Customer - Order", "Design POP-to-POP",
					"Issue TR (A)", "Issue TR (Z)", "Build Connection (Z)", "Build Connection (A)",
					"Notify Customer - GC Ready", "Update Billing", "Test With Customer" };
			EonDetailsPage.checkOrderTaskComplete(wavelength);
			// getDriver().findElement(By.linkText("Test With Customer")).click();
			// getDriver().switchTo().alert().accept();
			break;

		case "Private Line":
			String[] PL = { "Check Order", "Setup Billing", "Notify Customer - Order", "Design POP-to-POP",
					"Issue TR (A)", "Issue TR (Z)", "Build Connection (Z)", "Build Connection (A)",
					"Notify Customer - GC Ready", "Update Billing", "Notify Customer - Turn Up Complete" };
			      EonDetailsPage.checkOrderTaskComplete(PL);
			      break;
		case "Co-location/Mid-span Meet":
			
			String[] Colocation = { "Check Order", "Setup Billing", "Notify Customer - Order", "Design POP-to-POP",
					"Issue TR (A)", "Issue TR (Z)", "Build Connection (Z)", "Build Connection (A)",
					"Notify Customer - GC Ready", "Update Billing","Issue Work Package", "Issue Fiber and DSX Assignments"};
			EonDetailsPage.checkOrderTaskComplete(Colocation);
			break;
		default:
			// check order completion starts
			String[] tasksdefault = { "Check Order", "Setup Billing", "Notify Customer - Order", "Design POP-to-POP",
					"Issue TR (A)", "Issue TR (Z)", "Build Connection (Z)", "Build Connection (A)",
					"Notify Customer - GC Ready", "Update Billing" };

			EonDetailsPage.checkOrderTaskComplete(tasksdefault);
			break;
		}
			
		waitABit(2000);
		EonDetailsPage.btn_Refreshbtn.click();
		waitABit(2000);	
		
	}

	
	@Step
	public void check_order_tasks_completition_for_colocation() {
		System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		EonDetailsPage.cbx_CompleteOnClickAdmin.click();
		waitABit(2000);
		EonDetailsPage.btn_StartInHistory.click();
		waitABit(3000);
		EonDetailsPage.btn_RefreshInHistory.click();
		waitABit(3000);
		// check order completion starts
		String[] tasks1 = { "Check Order", 
							"Notify Customer - Order", 
							"Setup Billing","Issue Work Package", 
							"Issue Fiber and DSX Assignments", 
							"Implement/Verify Site Complete",
							"Notify Customer - GC Ready", 
							"Update Billing" };

		EonDetailsPage.checkOrderTaskComplete(tasks1);
		
		waitABit(2000);
		EonDetailsPage.btn_Refreshbtn.click();
		waitABit(2000);	
		
	}

	@Step
	public boolean order_status_should_move_to_In_Service(String expectedStatus) throws InterruptedException {
		boolean isStatusMatch = false;
		System.out.println("expectedStatus is :" + expectedStatus);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		Thread.sleep(2000);
		EonDetailsPage.getDriver().switchTo().frame("header_pane");
		System.out.println("Switched to header_pane");
		actualStatus = EonDetailsPage.lbl_Status.getText();
		Order_Item = EonDetailsPage.lbl_OrderNumber.getText() + EonDetailsPage.lbl_LineItem.getText();
		CircuitID = EonDetailsPage.lbl_CircuitID.getText();
		System.out.println(
				"##############################################  ORDER DETAILS #####################################################");
		System.out.println(
				"#                                                                                                                 #");
		System.out.println("# Product           : " + productSelected);
		System.out.println("# Order/Item        : " + Order_Item);
		// System.out.println("# LineItem : "+EonDetailsPage.lbl_LineItem.getText());
		System.out.println("# CircuitID 	    : " + CircuitID);
		System.out.println("# Status            : " + actualStatus);
		System.out.println(
				"#                                                                                                                 #");
		System.out.println(
				"########################### ***SCRIPTED BY: EON_TEST (Nanda Kumar & Saurabh Kumar)*** #############################");
		System.out.println(
				"######### ***serenity-cucumber-archetype using Selenium 2, JUnit and Cucumber-JVM with STAF dependency*** #########");

		EonDetailsPage.getDriver().switchTo().defaultContent();

		// switch back to ITEMS Page
		EonDetailsPage.getDriver().switchTo().window(ItemTAB);
		System.out.println("Order Page title : " + getDriver().getTitle());
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("nav_frame");
		EonDetailsPage.getDriver().findElement(By.id("navbar_refresh")).click();
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		waitABit(3000);
		
		String cd=System.getProperty("user.dir");
		String orderDetailsSnapshot = cd + "\\target\\EON-OrderStatus-Snapshot.jpg";

		File src = ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File(orderDetailsSnapshot));
		} catch (IOException e) {
			e.printStackTrace();
		}

		waitABit(2000);
		System.out.println("actualStatus is : " + actualStatus);
		if (actualStatus.contains(expectedStatus)) {
			isStatusMatch = true;
			System.out.println("Both are same ");
		}

		return isStatusMatch;

	}

	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
	// get current date time with Date()
	Date date = new Date();
	// Now format the date
	public String date1 = dateFormat.format(date);

	public void fn_auotslectText(List<WebElement> autotextddl, String textToSelect) throws InterruptedException {
		List<WebElement> list = autotextddl;
		System.out.println("Total auto suggestions==>" + list.size());
		for (int i = 0; i < list.size(); i++) {
			String autotexts = list.get(i).getText(); // to see the list of auto suggesting words
			System.out.println("The auto suggesting words are ==>" + autotexts);
			// Thread.sleep(3000);

			if (autotexts.contains(textToSelect)) {
				list.get(i).click(); // to click on any particular text in auto suggestion
				Thread.sleep(2000);
				break; // once it found the text comes out of the loop to save time as we found what we
						// need to click
			}
		}
	}

	public void add_Access_circuit() {
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_ItemsTab.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.ddl_Product.selectByVisibleText("Access Circuit");
		productSelected = EonDetailsPage.ddl_Product.getSelectedVisibleTextValue();
		assertTrue(productSelected.contains("Access Circuit"));
		EonDetailsPage.ddl_action.selectByVisibleText("ADD");
		waitABit(2000);
		EonDetailsPage.btn_productAdd.click();
	}

	public void configure_Access_circuit() {
		ItemTAB = getDriver().getWindowHandle();
		waitABit(1000);
		EonDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.ddl_SubProfile.selectByVisibleText("Access Circuit");
		assertTrue(EonDetailsPage.ddl_SubProfile.getSelectedVisibleTextValue().contains("Access Circuit"));
		EonDetailsPage.tbx_WantDate.sendKeys(date1);
		EonDetailsPage.tbx_IntervalDate.sendKeys(date1);
		IntDataContainer dat = get_data_for_page(EonItemDetailsPage).getContainer("AccessCircuitItemOrderDetailsPage");
		fillFields(EonItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
		waitABit(3000);

	}

	public void fetch_AccessCircuit_details() throws InterruptedException {
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		Thread.sleep(2000);
		EonDetailsPage.getDriver().switchTo().frame("header_pane");
		System.out.println("Switched to header_pane");
		actualStatus = EonDetailsPage.lbl_Status.getText();
		Order_Item = EonDetailsPage.lbl_OrderNumber.getText() + EonDetailsPage.lbl_LineItem.getText();
		AccessCircuitID = EonDetailsPage.lbl_CircuitID.getText();
		System.out.println(
				"############################################## Access Circuit Details #####################################################");
		System.out.println(
				"#                                                                                                                 #");
		System.out.println("# Order/Item        : " + Order_Item);
		// System.out.println("# LineItem : "+EonDetailsPage.lbl_LineItem.getText());
		System.out.println("# AccessCircuitID 	    : " + AccessCircuitID);
		System.out.println("# Status            : " + actualStatus);
		System.out.println("################################################################");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		// switch back to ITEMS Page
		EonDetailsPage.getDriver().switchTo().window(ItemTAB);
		System.out.println("Order Page title : " + getDriver().getTitle());
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("nav_frame");
		EonDetailsPage.getDriver().findElement(By.id("navbar_refresh")).click();
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		waitABit(3000);

	}

	public void add_product_with_AccessCircuitID(String Product, String Action) {
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_ItemsTab.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(5000);
		EonDetailsPage.ddl_Product.selectByVisibleText(Product);
		productSelected = EonDetailsPage.ddl_Product.getSelectedVisibleTextValue();
		assertTrue(productSelected.contains(Product));
		EonDetailsPage.ddl_action.selectByVisibleText(Action);
		waitABit(2000);
		EonDetailsPage.btn_productAdd.click();
		
		if (EonDetailsPage.isAlertPresents()) {
			getDriver().switchTo().alert().accept();
			getDriver().switchTo().defaultContent();
			}
		//EonDetailsPage.getAlert().accept();
		
		
	}

	@SuppressWarnings("unused")
	public void Check_Order_Task_completition() {
		System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		EonDetailsPage.cbx_CompleteOnClickAdmin.click();
		waitABit(2000);
		EonDetailsPage.btn_StartInHistory.click();
		waitABit(2000);
		EonDetailsPage.btn_RefreshInHistory.click();
		waitABit(2000);
		// check order completion starts
		if (productSelected.contains("Dedicated Internet")) {
			String[] tasks1 = { "Check Order", "Setup Billing", "Notify Customer - Order","Gather Order Details - TDE", "Assign IP/SA User",
					"Notify Customer - GC Ready", "Activation Bundle","Notify Customer - Turn Up Complete" };		
		EonDetailsPage.checkOrderTaskComplete(tasks1);
			}			
		else {
		String[] tasks1 = { "Check Order", "Setup Billing", "Notify Customer - Order", "Design POP-to-POP",
				"Issue TR (A)","Build Connection (A)","Test End-to-End",
				"Notify Customer - GC Ready", "Activation Bundle","Notify Customer - Turn Up Complete" };
		EonDetailsPage.checkOrderTaskComplete(tasks1);
		}

	}

	public void Check_Order_Task_completion_for_products(String Product) {
		System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		EonDetailsPage.cbx_CompleteOnClickAdmin.click();
		waitABit(2000);
		EonDetailsPage.btn_StartInHistory.click();
		waitABit(2000);
		EonDetailsPage.btn_RefreshInHistory.click();
		waitABit(2000);
		// check order completion starts
		
		
		switch(Product) {
		
		case "IP VRP": 
			String[] tasksForIPVRP = { "Check Order", "Gather Order Details - TDE", "Notify Customer - Order","Setup Billing", "Assign IP/SA User","Network Ready",
					"Notify Customer - GC Ready", "Activation Bundle","Notify Customer - Turn Up Complete" };		
		EonDetailsPage.checkOrderTaskComplete(tasksForIPVRP);
		
            break;
            
		case "Dedicated Internet":
			String[] tasksForDIA = { "Check Order", "Setup Billing", "Notify Customer - Order","Gather Order Details - TDE", "Assign IP/SA User",
					"Notify Customer - GC Ready", "Activation Bundle","Notify Customer - Turn Up Complete" };		
		EonDetailsPage.checkOrderTaskComplete(tasksForDIA);
		break;
			
		case "Co-location/Mid-span Meet":
			String[] tasksForColocation = { "Check Order", 
					"Notify Customer - Order", 
					"Setup Billing","Issue Work Package", 
					"Issue Fiber and DSX Assignments", 
					"Implement/Verify Site Complete",
					"Notify Customer - GC Ready", 
					"Update Billing" };

		EonDetailsPage.checkOrderTaskComplete(tasksForColocation);
			break;
			
		case "Private Line":
			break;
			
		case "WDM/Lambda":
			break;
		case "EtherExtend":
			String[] EtherExtendTask= {"Check Order", "Issue ASR", "Setup Billing", "Notify Customer - Order", "Wait for FOC","Notify Customer - FOC (A)","Notify Customer - 72 Hrs (A)", "Confirm Vendor Completion", "Loop Accept (A)",
										"Notify Customer - GC Ready", "Activation Bundle","Notify Customer - Turn Up Complete"};
    		EonDetailsPage.checkOrderTaskComplete(EtherExtendTask);
    		break;
        default: 
    		String[] tasks1 = { "Check Order", "Setup Billing", "Notify Customer - Order", "Design POP-to-POP",
    				"Issue TR (A)","Build Connection (A)","Test End-to-End",
    				"Notify Customer - GC Ready", "Activation Bundle" };
    		EonDetailsPage.checkOrderTaskComplete(tasks1);
            break; 
        } 
					
	}
	
	@Step
	public void select_the_subProfile(String SubProfile) {
		ItemTAB = getDriver().getWindowHandle();
		waitABit(1000);
		EonDIAItemDetailsPage.Windowhandle("Item");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		System.out.println("Sub_Profile"+SubProfile);
		if(SubProfile.equals("UNI") || SubProfile.equals("Sub-Interface")) {
			EonDIAItemDetailsPage.ddl_SubProfileUNI.selectByVisibleText(SubProfile);
			assertTrue(EonDIAItemDetailsPage.ddl_SubProfileUNI.getSelectedVisibleTextValue().contains(SubProfile));
		}else {
		EonDIAItemDetailsPage.ddl_SubProfile1.selectByVisibleText(SubProfile);
		assertTrue(EonDIAItemDetailsPage.ddl_SubProfile1.getSelectedVisibleTextValue().contains(SubProfile));
		}
	}
	
	@Step
	public void select_the_configuaration_for_dedicated_Internet() throws InterruptedException {
		waitABit(5000);
		IntDataContainer dat = get_data_for_page(EonDIAItemDetailsPage).getContainer("DedicatedInternet");
		fillFields(EonDIAItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
		System.out.println("DIA selected few conifg");
		waitABit(3000);	
		//EonDetailsPage.tbx_AccessCircuitID.sendKeys("2006839106");
		EonDetailsPage.tbx_AccessCircuitID.sendKeys(AccessCircuitID);
		EonDetailsPage.btn_Save.click();
		Thread.sleep(7000);
		IntDataContainer data = get_data_for_page(EonDIAItemDetailsPage).getContainer("DedicatedInternetAfterSave");
		fillFields(EonDIAItemDetailsPage, data.getMandatoryFieldsFromAllContainers());
	}
	
	@Step
	public void select_the_configuaration_for_IP_VRP() throws InterruptedException {
		waitABit(5000);
		IntDataContainer dat = get_data_for_page(EonIPVRPItemDetailsPage).getContainer("IPVRP");
		fillFields(EonIPVRPItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
		System.out.println("IP VRP selected few conifg");
		waitABit(3000);
		//EonDetailsPage.tbx_AccessCircuitID.sendKeys("2006804655");
		EonDetailsPage.tbx_AccessCircuitID.sendKeys(AccessCircuitID);
		EonDetailsPage.btn_Save.click();
		Thread.sleep(7000);
		IntDataContainer data = get_data_for_page(EonIPVRPItemDetailsPage).getContainer("IPVRPAfterSave");
		fillFields(EonIPVRPItemDetailsPage, data.getMandatoryFieldsFromAllContainers());
		waitABit(5000);
	
	}
	
	@Step
	public void SendEmailhavingOrderDetails() throws InterruptedException {
		
		Thread.sleep(10000);		
		
		getDriver().switchTo().frame("workspacePane");
		System.out.println("switched to workspace pane");
		getDriver().switchTo().frame("entry_pane");
		System.out.println("switched to entry pane");
		
		Point point = getDriver().findElement(By.xpath("html/body/form/table")).getLocation();
		int x = point.getX();
		int y = point.getY();
		int width = getDriver().findElement(By.xpath("html/body/form/table")).getSize().getWidth();
		int height = getDriver().findElement(By.xpath("html/body/form/table")).getSize().getHeight();		
		
		String usercwd = System.getProperty("user.dir");
        System.out.println("Current User Working Directory Path: " + usercwd);
        String EONCTLLogo = usercwd + "\\src\\test\\resources\\EON-GC-CenturyLinkLogo.jpg";
        String EONGCOrderDetails = usercwd + "\\target\\EON-GC-OrderDetails.jpg";
        String EONGCOrderDetailsCropped = usercwd + "\\target\\EON-GC-OrderDetails-Cropped.jpg";
		
		
		File src= ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(src, new File(EONGCOrderDetails));
			Image orig = ImageIO.read(new File(EONGCOrderDetails));
			BufferedImage bi = new BufferedImage(width, height, BufferedImage.OPAQUE);
			bi.getGraphics().drawImage(orig, 0, 0, width, height, x, y, x + width, y + height, null);
			ImageIO.write(bi, "jpg", new File(EONGCOrderDetailsCropped));
		}

		catch (IOException e)
		{
			System.out.println(e.getMessage());

		}
		
		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "nnanda.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC Automation Regression passed_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));
			 msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));

			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+

                            "<pr>Hi All,</pr>\n"+

                            "<br><br>\n"+

							"<pr>EON-GC Automation Regression passed. Please find below order details,</pr>\n" +

                            "<br><br>\n"+

                            "<b><u>EON-GC Order Details:</u></b>\n"+

                            "<br><br>\n"+

                            "<table border= 2 cellpadding= 2 cellspacing= 0>\n"+

                            "<tr><td colspan = 2>\n"+

                            "<img  align =center src=\"cid:EON-GC-CenturyLinklogo\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

                            "</td></tr>\n"+                                 

                            "<tr><td align= left valign=top style=background-color:#006600;color:#FFFFFF;>Product Name</td><td align= left valign=top style=background-color:#FFEBD6;color:#000000;>" + productSelected + "</td></tr>\n"+

                            "<tr><td align= left valign=top style=background-color:#006600;color:#FFFFFF;>Order/Item</td><td align= left valign=top style=background-color:#FFEBD6;color:#000000;>" + Order_Item +"</td></tr>\n"+

                            "<tr><td align= left valign=top style=background-color:#006600;color:#FFFFFF;>Circuit ID</td><td align= left valign=top style=background-color:#FFEBD6;color:#000000;>" + CircuitID + "</td></tr>\n"+

                            "<tr><td align= left valign=top style=background-color:#006600;color:#FFFFFF;>Status</td><td align= left valign=top style=background-color:#FFEBD6;color:#000000;>"+ actualStatus +"</td></tr>\n"+

                            //"<tr><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By: EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></tr>\n"+

                            "</table>\n"+

                            "<br>\n"+
                            
							"<b><u>EON-GC Order's Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:EON-GC-OrderDetails\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This sanity mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Nanda Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("EON-GC-CenturyLinklogo", EONCTLLogo);
			mapinlineImages.put("EON-GC-OrderDetails", EONGCOrderDetails);
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
	}

	@Step
	public void verify_LEXMWO_field() {
		
		assertTrue(getDriver().findElement(By.id("main:workOrderNumberLabel")).isDisplayed());
		System.out.println("LEXM WO="+getDriver().findElement(By.id("main:workOrderNumberLabel")).getText());
	}

	@Step
	public void select_the_configuaration_template_for_EtherExtend() throws InterruptedException {
		
		IntDataContainer data = get_data_for_page(EonItemDetailsPage).getContainer("EtherExtendItemDetailsPage");
		fillFields(EonItemDetailsPage, data.getMandatoryFieldsFromAllContainers());
		
		getDriver().switchTo().window("premAdd");
	    System.out.println("Switched to child window");
	    getDriver().manage().window().maximize();
		EonItemDetailsPage.getDriver().switchTo().defaultContent();
		EonItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonItemDetailsPage.ddl_editAll.selectByVisibleText("N");
		EonItemDetailsPage.tbx_SiteName.sendKeys("Test Automation location");
		EonItemDetailsPage.ddl_Addresscountry.selectByVisibleText("Ireland");
		EonItemDetailsPage.tbx_SitephoneNumber.sendKeys("4029987779");
		EonItemDetailsPage.btn_SaveConfig.click();		
		waitABit(5000);
		EonItemDetailsPage.btn_close.click();
		System.out.println("closed the address window");
		EonDIAItemDetailsPage.Windowhandle("Item");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
        EonItemDetailsPage.btn_mainsavebutton.click();
        Thread.sleep(6000);
        EonItemDetailsPage.tbx_bandwidthCode.clear();
        waitABit(2000);
        EonItemDetailsPage.tbx_bandwidthCode.sendKeys("10M");
        waitABit(2000);
        EonItemDetailsPage.btn_mainsavebutton.click();
        waitABit(3000);
        EonItemDetailsPage.btn_mainsavebutton.click();
        waitABit(3000);
        System.out.println("Saved the config without losing the existing values");
	}

	
	@Step
	public void Configure_initial_detailsTAB_info()
			throws InterruptedException {
		
		waitABit(2000);
		EonDetailsPage.Windowhandle("Home");
		waitABit(2000);
		System.out.println("control retun back to User steps");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		System.out.println("Switched to TAB pane");
		EonDetailsPage.lbl_ordersTAB.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.btn_NEW.click();
		System.out.println("Switched to Entry pane and clicked on NEW");
		EonDetailsPage.Windowhandle("Order");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		
		IntDataContainer dat1 = get_data_for_page(EonDetailsPage).getContainer("EONOrderDetailsPageAddPrimaryContacts");
		fillFields(EonDetailsPage, dat1.getMandatoryFieldsFromAllContainers());
		waitABit(15000);
		System.out.println("waited 15 seconds");
		
		EonDetailsPage.ddl_salesRegion.selectByVisibleText("North America");
		System.out.println(EonDetailsPage.ddl_salesRegion.getSelectedValue());
		assertTrue(EonDetailsPage.ddl_salesRegion.getSelectedVisibleTextValue().contains("North America"));
		waitABit(3000);
		EonDetailsPage.ddl_BillingSystem.selectByVisibleText("BillViz");
		System.out.println(EonDetailsPage.ddl_BillingSystem.getSelectedValue());
		assertTrue(EonDetailsPage.ddl_BillingSystem.getSelectedVisibleTextValue().contains("BillViz"));
		waitABit(1000);
		EonDetailsPage.tbx_receivedDate.sendKeys(date1);
		EonDetailsPage.tbx_signedDate.sendKeys(date1);

		EonDetailsPage.tbx_gcodContactName.sendKeys("Naresh");
		waitABit(2000);
		List<WebElement> gcodContactName = getDriver()
				.findElements(By.xpath("//table[contains(@id, 'main:j_id199:')]//td"));
		fn_auotslectText(gcodContactName, "Naresh");

		EonDetailsPage.tbx_supportName.sendKeys("N Nanda Kumar");
		waitABit(2000);
		List<WebElement> SalesSupportContact = getDriver()
				.findElements(By.xpath("//table[contains(@id, 'main:j_id235:')]//td"));
		fn_auotslectText(SalesSupportContact, "Nanda");

		waitABit(2000);
		EonDetailsPage.tbx_repName.sendKeys("N Nanda Kumar");
		waitABit(2000);
		List<WebElement> SalesRepContact = getDriver()
				.findElements(By.xpath("//table[contains(@id, 'main:j_id226:')]//td"));
		fn_auotslectText(SalesRepContact, "Nanda");
		waitABit(2000);
		IntDataContainer dat = get_data_for_page(EonDetailsPage).getContainer("EONOrderDetailsPage");
		fillFields(EonDetailsPage, dat.getMandatoryFieldsFromAllContainers());
				
	    Thread.sleep(10000);
	    System.out.println("waited 10 seconds to click Save button");
	    
	    Actions saveButton = new Actions(getDriver());
	    saveButton.moveToElement(getDriver().findElement(By.name("main:savebutton"))).click().build().perform();
	        
		System.out.println("Order is saved successfully");
		
		waitABit(10000);
		
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		Thread.sleep(2000);
		EonDetailsPage.getDriver().switchTo().frame("header_pane");
		System.out.println("Order#:"+ EonDetailsPage.lbl_OrderNumber1.getText());
		EonDetailsPage.getDriver().switchTo().defaultContent();
	
	}
	
	@Step
	public void switch_to_ITEM_Tab_and_select_the_IPGateWayRVASite_and_type_of_action() {
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		System.out.println("Switched to tab pane");
	
		EonDetailsPage.lbl_ItemsTab.click();
		System.out.println("Clicked Items tab");
		waitABit(5000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		System.out.println("Switched to Entry pane");
		waitABit(2000);	
		EonDetailsPage.ddl_Product.selectByVisibleText("IP GateWay - RVA Site");
		productSelected = EonDetailsPage.ddl_Product.getSelectedVisibleTextValue();
		assertTrue(productSelected.contains("IP GateWay - RVA Site"));
		EonDetailsPage.ddl_action.selectByVisibleText("ADD");
		waitABit(2000);
		EonDetailsPage.btn_productAdd.click();

	}

	
	@Step
	public void select_the_configuaration_for_IPGateWayRVASite_AC1() throws InterruptedException {
		waitABit(5000);
		ItemTAB = getDriver().getWindowHandle();
		waitABit(3000);
		EonDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		System.out.println("Switched to entry_pane");	
		waitABit(5000);
		
		EonIPGateWayRVASiteItemDetailsPage.btn_wantdate.click();
		EonIPGateWayRVASiteItemDetailsPage.lnk_wantdateSelect.click();
		EonIPGateWayRVASiteItemDetailsPage.btn_Intervaldate.click();
		EonIPGateWayRVASiteItemDetailsPage.lnk_IntervaldateSelect.click();			
		EonIPGateWayRVASiteItemDetailsPage.btn_mainsavebutton.click();

//		IntDataContainer dat = get_data_for_page(EonIPGateWayRVASiteItemDetailsPage).getContainer("EonIPGateWayRVASiteUS304731AC1");
//		fillFields(EonIPGateWayRVASiteItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
//		EonIPGateWayRVASiteItemDetailsPage.WaitForPageToLoad(60);
		waitABit(10000);
		EonIPGateWayRVASiteItemDetailsPage.cbx_sab.click();

//		IntDataContainer data = get_data_for_page(EonIPGateWayRVASiteItemDetailsPage).getContainer("EonIPGateWayRVASiteUS304731AC1IPVRPAfterSave");
//		fillFields(EonIPGateWayRVASiteItemDetailsPage, data.getMandatoryFieldsFromAllContainers());
		waitABit(8000);
		
	}
	
	@Step
	public void select_the_configuaration_for_IPGateWayRVASite_US304733() throws InterruptedException {
		waitABit(5000);
		ItemTAB = getDriver().getWindowHandle();
		waitABit(3000);
		EonDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		System.out.println("Switched to entry_pane");	
		waitABit(5000);
		
		EonIPGateWayRVASiteItemDetailsPage.btn_wantdate.click();
		EonIPGateWayRVASiteItemDetailsPage.lnk_wantdateSelect.click();
		EonIPGateWayRVASiteItemDetailsPage.btn_Intervaldate.click();
		EonIPGateWayRVASiteItemDetailsPage.lnk_IntervaldateSelect.click();			
		EonIPGateWayRVASiteItemDetailsPage.btn_mainsavebutton.click();

		waitABit(8000);
		
	}
	
	

	
	@Step
	public boolean validate_that_lov_for_Access_Type_is_Customer_Provided_Access_Broadband_and_Cellular() {
		
		String[] exp = {"Customer Provided", "Broadband", "Cellular"};
		WebElement dropdown = getDriver().findElement(By.xpath("//select[@name='main:acessTypeId']"));    
		Select select = new Select(dropdown); 
		java.util.List<WebElement> options = select.getOptions(); 
		for(WebElement item:options) 
		{ 
			for (int i=0; i<exp.length; i++){
				if (item.getText().equals(exp[i])){
					assertTrue(item.getText().equals(exp[i]));
					System.out.println(item.getText());
				}
			}
		}  				
	    
	    EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.click();    

		boolean Aceess_Type_Added = EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.isPresent();
	
		assertTrue(Aceess_Type_Added);
		WebElement access_type = getDriver().findElement(By.xpath("//select[@name='main:acessTypeId']"));
		
		highLighElement(access_type);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessTypeValues.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>LOV for 'Access Type' is  - Customer Provided Access, Broadband and Cellular.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessTypeValues\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessTypeValues", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessTypeValues.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Aceess_Type_Added;
			

	}
	
	
	@Step
	public boolean validate_that_If_user_selects_Broadband_for_Access_Type_display_a_new_mandatory_text_box_with_the_label_Access_SWIFT_ID() throws InterruptedException {

		
		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Broadband");
		
		Thread.sleep(5000);
		
		boolean Access_Swift_ID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
	
		assertTrue(Access_Swift_ID);
		WebElement accessSwiftID = getDriver().findElement(By.xpath("//input[@name='main:accessSwiftId']"));
		
		highLighElement(accessSwiftID);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessBroadbandSwiftID.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>If user selects Broadband for Access Type, display a new mandatory text box with the label Access SWIFT ID.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessBroadbandSwiftID\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessBroadbandSwiftID", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessBroadbandSwiftID.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Access_Swift_ID;
			

	}
	
	@Step
	public boolean for_Access_Type_equal_to_Customer_Provided_Access_do_not_display_Access_SWIFT_ID() throws InterruptedException {
	
		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Customer Provided");
		
		Thread.sleep(5000);
		
		
		WebElement accessType = getDriver().findElement(By.xpath("//select[@name='main:acessTypeId']"));
		
		boolean Access_SwiftID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
		
		Assert.assertFalse(Access_SwiftID);
		
		
		highLighElement(accessType);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCPASwiftID.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>For  Access Type = 'Customer Provided', do not display 'Access SWIFT ID'.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessCPASwiftID\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessCPASwiftID", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCPASwiftID.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Access_SwiftID;
			

	}
	
	@Step
	public boolean validate_that_If_user_selects_Cellular_for_Access_Type_display_a_new_mandatory_text_box_with_the_label_Access_SWIFT_ID() throws InterruptedException {	
		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Cellular");
		
		Thread.sleep(5000);
		
		boolean Access_Swift_ID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
	
		assertTrue(Access_Swift_ID);
		WebElement accessSwiftID = getDriver().findElement(By.xpath("//input[@name='main:accessSwiftId']"));
		
		highLighElement(accessSwiftID);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCellularSwiftID.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>If user selects Cellular for Access Type, display a new mandatory text box with the label Access SWIFT ID.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessCellularSwiftID\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessCellularSwiftID", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCellularSwiftID.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Access_Swift_ID;
			

	}	
	
	@Step
	public boolean validate_that_with_Cellular_as_Access_type_Access_SWIFT_ID_text_box_to_accept_only_the_numbers_starting_with_thirty_three_with_total_nine_digit_number() throws InterruptedException {

		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Cellular");
		
		Thread.sleep(5000);
		
		boolean Access_Swift_ID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
	
		assertTrue(Access_Swift_ID);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.sendKeys("333456789");
		
		WebElement accessSwiftID = getDriver().findElement(By.xpath("//input[@name='main:accessSwiftId']"));
		
		highLighElement(accessSwiftID);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCellularSwiftIDNineDigits.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>For 'Access Type' as 'Cellular', 'Access SWIFT ID' text box to accept only the numbers starting with 33## (9 digit number).</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessCellularSwiftIDNineDigits\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessCellularSwiftIDNineDigits", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCellularSwiftIDNineDigits.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Access_Swift_ID;
			

	}	
	
	@Step
	public boolean validate_that_with_Broadband_as_Access_type_Access_SWIFT_ID_text_box_to_accept_only_the_numbers_starting_with_thirty_three_with_total_nine_digit_number() throws InterruptedException {

		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Broadband");
		
		Thread.sleep(5000);
		
		boolean Access_Swift_ID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
	
		assertTrue(Access_Swift_ID);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.sendKeys("334567890");
		
		WebElement accessSwiftID = getDriver().findElement(By.xpath("//input[@name='main:accessSwiftId']"));
		
		highLighElement(accessSwiftID);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessBroadbandSwiftIDNineDigits.jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>For 'Access Type' as 'Broadband', 'Access SWIFT ID' text box to accept only the numbers starting with 33## (9 digit number).</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessBroadbandSwiftIDNineDigits\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessBroadbandSwiftIDNineDigits", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessBroadbandSwiftIDNineDigits.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Access_Swift_ID;
			

	}	
	
	@Step
	public boolean validate_that_with_Broadband_as_Access_Type_Validate_Error_message_if_we_dont_start_number_with_thirty_three_for_Access_Swift_ID() throws InterruptedException {

		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Broadband");
		
		Thread.sleep(5000);
		
		boolean Access_Swift_ID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
	
		assertTrue(Access_Swift_ID);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.sendKeys("123456789");
		
		WebElement accessSwiftID = getDriver().findElement(By.xpath("//input[@name='main:accessSwiftId']"));
		
		highLighElement(accessSwiftID);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_expediteTicketNumber.click();
		
		Thread.sleep(2000);
		
		try {
		// This code will capture screenshot of current screen		
		BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			    
		// This will store screenshot on Specific location
		ImageIO.write(image, "jpg", new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessBroadbandSwiftIDNotStatingwith33ErrMsg.jpg")); 
		
		System.out.println("Full Desktop screenshot saved!");
		
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
			
		
		getDriver().switchTo().alert().accept();
			
		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+

                            "<pr>Hi All,</pr>\n"+

                            "<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>For 'Access Type' as 'Broadband', if 'Access SWIFT ID' the numbers entered not starting with 33## (9 digit number) then validation error should display as <i>'Please enter a valid Acess Swift Id. Correct format should start with 33 and 9 digit number. Example: 334567890.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessBroadbandSwiftIDNotStatingwith33ErrMsg\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessBroadbandSwiftIDNotStatingwith33ErrMsg", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessBroadbandSwiftIDNotStatingwith33ErrMsg.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		
		return Access_Swift_ID;
			

	}	
	
	@Step
	public boolean validate_that_with_Cellular_as_Access_Type_Validate_Error_message_if_we_dont_start_number_with_thirty_three_for_Access_Swift_ID() throws InterruptedException {

		
		EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.selectByVisibleText("Cellular");
		
		Thread.sleep(5000);
		
		boolean Access_Swift_ID = EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.isPresent();
	
		assertTrue(Access_Swift_ID);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_access_swift_id.sendKeys("123456789");
		
		WebElement accessSwiftID = getDriver().findElement(By.xpath("//input[@name='main:accessSwiftId']"));
		
		highLighElement(accessSwiftID);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_expediteTicketNumber.click();
		
		Thread.sleep(2000);
		
		try {
		// This code will capture screenshot of current screen		
		BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			    
		// This will store screenshot on Specific location
		ImageIO.write(image, "jpg", new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCellularSwiftIDNotStatingwith33ErrMsg.jpg")); 
		
		System.out.println("Full Desktop screenshot saved!");
		
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
			
		
		getDriver().switchTo().alert().accept();

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+

                            "<pr>Hi All,</pr>\n"+

                            "<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>For 'Access Type' as 'Cellular', if 'Access SWIFT ID' the numbers entered not starting with 33## (9 digit number) then validation error should display as <i>'Please enter a valid Acess Swift Id. Correct format should start with 33 and 9 digit number. Example: 334567890.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

                            "<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessCellularSwiftIDNotStatingwith33ErrMsg\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessCellularSwiftIDNotStatingwith33ErrMsg", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessCellularSwiftIDNotStatingwith33ErrMsg.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
		
		return Access_Swift_ID;
			

	}
	
	@Step
	public boolean validate_that_A_new_drop_down_with_the_label_Access_Type_is_added_below_the_SAB_check_box() {

		boolean Aceess_Type_Added = EonIPGateWayRVASiteItemDetailsPage.ddl_access_type.isPresent();
	
		assertTrue(Aceess_Type_Added);
		WebElement access_type = getDriver().findElement(By.xpath("//select[@name='main:acessTypeId']"));
		
		highLighElement(access_type);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);

		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessType.jpg"));
		} catch (IOException e) {

			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304731_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304731- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>Validate that a new drop down with the label Access Type is added below the 'SAB' check box.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteAccessType\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteAccessType", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteAccessType.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return Aceess_Type_Added;
			

	}	
	
	@Step
	public boolean validate_that_under_IPSEC_section_a_new_text_box_is_added_with_the_label_CPE_Public_IP_Gateway_Address() {

		boolean CPEPublicIPGatewayAddress_Added = EonIPGateWayRVASiteItemDetailsPage.tbx_CPEPublicIPGatewayAddress.isPresent();
	
		assertTrue(CPEPublicIPGatewayAddress_Added);
		
		getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']")).click();
		
		WebElement CPEPublicIPGatewayAddress = getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']"));
		
		highLighElement(CPEPublicIPGatewayAddress);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteCPEPublicIPGatewayAddressTbx.jpg"));
		} catch (IOException e) {

			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304733- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>Validate that under IPSEC section a new text box is added with the label 'CPE Public IP Gateway Address'.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteCPEPublicIPGatewayAddressTbx\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Nanda Kumar(AB54030) & Saurabh Kumar(SXKUM64))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteCPEPublicIPGatewayAddressTbx", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteCPEPublicIPGatewayAddressTbx.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return CPEPublicIPGatewayAddress_Added;
			

	}
	
	@Step
	public boolean validate_CPE_Public_IP_Gateway_Address_is_optional() {

		boolean CPEPublicIPGatewayAddressOptional_Added = EonIPGateWayRVASiteItemDetailsPage.lbl_CPEPublicIPGatewayAddress.isPresent();
	
		assertTrue(CPEPublicIPGatewayAddressOptional_Added);
		
		getDriver().findElement(By.xpath("//label[contains(@for,'main:cpeGatewayIp')]")).click();
		
		WebElement CPEPublicIPGatewayAddress = getDriver().findElement(By.xpath("//label[contains(@for,'main:cpeGatewayIp')]"));
		
		highLighElement(CPEPublicIPGatewayAddress);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteCPEPublicIPGatewayAddressTbxOptional.jpg"));
		} catch (IOException e) {

			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304733- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>Validate 'CPE Public IP Gateway Address' is optional.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteCPEPublicIPGatewayAddressTbxOptional\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Saurabh Kumar(SXKUM64) & Nanda Kumar(AB54030))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteCPEPublicIPGatewayAddressTbxOptional", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteCPEPublicIPGatewayAddressTbxOptional.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return CPEPublicIPGatewayAddressOptional_Added;
			

	}
	
	@Step
	public boolean validate_cpe_Public_IP_Gateway_Address_is_optional_to_accept_only_the_valid_IP_addresses() {

		boolean CPEPublicIPGatewayAddress_ValidValue = EonIPGateWayRVASiteItemDetailsPage.tbx_CPEPublicIPGatewayAddress.isPresent();
	
		assertTrue(CPEPublicIPGatewayAddress_ValidValue);
		
		getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']")).click();
		
		getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']")).sendKeys("166.164.48.56/31");		
				
		WebElement CPEPublicIPGatewayAddressValidValue = getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']"));
		
		highLighElement(CPEPublicIPGatewayAddressValidValue);
		
		File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteCPEPublicIPGatewayAddressValidValue.jpg"));
		} catch (IOException e) {

			e.printStackTrace();
		}

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304733- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>Validate 'CPE Public IP Gateway Address' is optional to accept only the valid IP addresses.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:IPGateWayRVASiteCPEPublicIPGatewayAddressValidValue\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Saurabh Kumar(SXKUM64) & Nanda Kumar(AB54030))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("IPGateWayRVASiteCPEPublicIPGatewayAddressValidValue", System.getProperty("user.dir")+"\\target\\IPGateWayRVASiteCPEPublicIPGatewayAddressValidValue.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

		getDriver().switchTo().defaultContent();
		System.out.println("switched to default content");
		
		return CPEPublicIPGatewayAddress_ValidValue;
			

	}
	
	@Step
	public boolean if_invalid_format_value_is_entered_for_CPE_Public_IP_Gateway_Address_then_validate_error_message_as_Invalid_Ip_Address_CIDR_Format_XXX_XXX_XXX_XXX_YY_Required() throws InterruptedException {

		boolean CPEPublicIPGatewayAddress_InvalidValue = EonIPGateWayRVASiteItemDetailsPage.tbx_CPEPublicIPGatewayAddress.isPresent();
		
		assertTrue(CPEPublicIPGatewayAddress_InvalidValue);
		
		getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']")).click();
		
		getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']")).sendKeys("166.164.48.56");
		
		getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']")).click();
				
		WebElement CPEPublicIPGatewayAddressInvalidValue = getDriver().findElement(By.xpath("//input[@name='main:cpeGatewayIp']"));
		
		highLighElement(CPEPublicIPGatewayAddressInvalidValue);
		
		EonIPGateWayRVASiteItemDetailsPage.tbx_CPEPublicIPAddress.click();
		
		Thread.sleep(2000);
		
		try {
		// This code will capture screenshot of current screen		
		BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
			    
		// This will store screenshot on Specific location
		ImageIO.write(image, "jpg", new File(System.getProperty("user.dir")+"\\target\\CPEPublicIPGatewayAddressInvalidValueErrMsg.jpg")); 
		
		System.out.println("Full Desktop screenshot saved!");
		
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}
			
		
		getDriver().switchTo().alert().accept();

		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e) {

			e.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "saurabh.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing Scenario is passed in QA4_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+

                            "<pr>Hi All,</pr>\n"+

                            "<br><br>\n"+

							"<pr>EON-GC 2019-04 (APR) SMR_US304733_Automation Continuous Integration Testing scenario is passed in QA4 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US304733- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>If invalid format value is entered for 'CPE Public IP Gateway Address' then Validate error message as: 'Invalid IP Address: CIDR Format XXX.XXX.XXX.XXX/YY Required'.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

                            "<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:CPEPublicIPGatewayAddressInvalidValueErrMsg\" alt = Scripted By: Saurabh Kumar(SXKUM64) title = Scripted By: Saurabh Kumar(SXKUM64) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Saurabh Kumar(SXKUM64) & Nanda Kumar(AB54030))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Saurabh Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("CPEPublicIPGatewayAddressInvalidValueErrMsg", System.getProperty("user.dir")+"\\target\\CPEPublicIPGatewayAddressInvalidValueErrMsg.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
		
		return CPEPublicIPGatewayAddress_InvalidValue;
			

	}

	@Step
	public void contacts_validation_Hours_of_Availability(String tcid) {
		System.out.println("**********************CONTACTS TAB****************");
		waitABit(5000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_ContactsTAB.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDIAItemDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.btn_new.click();
		waitABit(2000);
		EonDetailsPage.Windowhandle("Create New Contact");
		getDriver().switchTo().defaultContent(); 
		getDriver().manage().window().maximize();
		if(tcid.equals("TC377902")||tcid.equals("TC377904")) {
		if(tcid.equals("TC377902")){
		assertTrue(EonDetailsPage.tbx_hoursOfAvailability.isDisplayed());
		System.out.println("tbx_hoursOfAvailability is available");
		highLighElement(EonDetailsPage.tbx_hoursOfAvailability);
		assertTrue(EonDetailsPage.tbx_hoursOfAvailability.getAttribute("maxlength").equals("30"));
		 }
		 if(tcid.equals("TC377904")) {
			assertTrue(EonDetailsPage.tbx_hoursOfAvailability.isDisplayed());
			System.out.println("tbx_hoursOfAvailability is available");
			EonDetailsPage.tbx_hoursOfAvailability.sendKeys("EONAutomationTest123455");
			highLighElement(EonDetailsPage.tbx_hoursOfAvailability);
		 }
        File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\hoursOfAvailability.jpg"));
		} catch (IOException e) {

			e.printStackTrace();
		}
		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e1) {

			e1.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "nnanda.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-05 (MAY) SMR_US312499_Automation Continuous Integration Testing Scenario is passed in QA3_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-05 (MAY) SMR_US312499_Automation Continuous Integration Testing scenario is passed in QA3 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US312499- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>Validate EON item level contact screen (Item level -> Contacts tab -> New button), Add a new label 'Hours of Availability' (below Notification label) along with an optional Text Box.</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:hoursOfAvailability\" alt = Scripted By: Nanda Kumar(AB54030) title = Scripted By: Nanda Kumar(AB54030) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Saurabh Kumar(SXKUM64) & Nanda Kumar(AB54030))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Nanda Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("hoursOfAvailability", System.getProperty("user.dir")+"\\target\\hoursOfAvailability.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

	}	
		
		if (tcid.equals("TC377905")) {
			Select s = null;
			try {
				s = new Select(getDriver().findElement(By.xpath("//select[@id='notifyCode']")));
			} catch (Exception e2) {
				e2.printStackTrace();
				s = new Select(getDriver().findElement(By.xpath("//select[@id='notifyCode']")));
			}
			List<WebElement> ddl = s.getOptions();
			System.out.println("Number of values in Notification ddl: " + ddl.size());
			for (int i = 0; i < ddl.size(); i++) {
				if (ddl.get(i).getText().equals("Email - Text")) {
					System.out.println("Newly added value is avalibale in Notification dropdown");
					assertEquals("Email - Text", ddl.get(i).getText());
					EonDetailsPage.ddl_notification.selectByVisibleText("Email - Text");
					assertEquals("Email - Text", EonDetailsPage.ddl_notification.getSelectedVisibleTextValue());
					highLighElement(EonDetailsPage.ddl_notification);
				}
			}

			File src= ((TakesScreenshot) getDriver()).getScreenshotAs(OutputType.FILE);
			
			try {
				FileUtils.copyFile(src, new File(System.getProperty("user.dir")+"\\target\\hoursOfAvailability.jpg"));
			} catch (IOException e) {

				e.printStackTrace();
			}
			
		
		SimpleDateFormat sdobj = new SimpleDateFormat("MM/dd/yyyy 'at' hh:mm aa z");

		Date dateobj = new Date();
		
		sdobj.setTimeZone(TimeZone.getTimeZone("IST"));

		System.out.println(sdobj.format(dateobj));

		System.out.println("Sending Order Details in email...");

		InetAddress ip;

		String hostname = null;

		String hostIPAddress = null;

		try {

			ip = InetAddress.getLocalHost();

			hostname = ip.getHostName();

			hostIPAddress = ip.getHostAddress();

		} catch (UnknownHostException e1) {

			e1.printStackTrace();

		}

		java.util.Properties props = new java.util.Properties();

		props.put("mail.smtp.host", "mailgate.uswc.uswest.com");

		Session session = Session.getDefaultInstance(props, null);

		String from = "nnanda.kumar@centurylink.com";
		//String from = "saurabh.kumar@centurylink.com";

		String subject = "EON-GC 2019-05 (MAY) SMR_US312499_Automation Continuous Integration Testing Scenario is passed in QA3_" + sdobj.format(dateobj);

		Message msg = new MimeMessage(session);

		try {

			msg.setFrom(new InternetAddress(from));

			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nnanda.kumar@CenturyLink.com"));
			//msg.setRecipients(Message.RecipientType.TO,InternetAddress.parse("EON_TEST@CenturyLink.com,Praveen_L3_Test@CenturyLink.com"));
			
			//msg.setRecipients(Message.RecipientType.CC, InternetAddress.parse("vivek.jain@centurylink.com,keith.lamle@centurylink.com,Praveen.K.Chinni@centurylink.com,sheela.mamidi@centurylink.com,bhanup.pathipati@level3.com,rajesh.kollipara2@level3.com,lokesh.thakkalapatti@centurylink.com"));
			
			msg.setSubject(subject);

			MimeMultipart multipart = new MimeMultipart("related");

			BodyPart msgBodyPart = new MimeBodyPart();

			String htmlText = "<html>\n" +	
			
            				"<Head></head>\n"+

                            "<body>\n"+							
							
							"<pr>Hi All,</pr>\n"+

							"<br><br>\n"+

							"<pr>EON-GC 2019-05 (MAY) SMR_US312499_Automation Continuous Integration Testing scenario is passed in QA3 environment.</pr>\n" +

							"<br><br>\n"+

							"<pr><b><u>US312499- Acceptance Criteria:</u></b></pr>\n"+
							
							"<pr><ul><li><b>EON item level contact screen: Add 'Email and Text' as a new drop-down option in 'Notification' list..</i></b></li></ul></pr>\n"+
                            
							"<br><br>\n"+

							"<pr>Please find below the validation snapshot,</pr>\n" +

							"<br><br>\n"+
                            
							"<b><u>Validation Snapshot Details:</u></b>\n" +

							"<br><br>\n" +
							
							"<table border= 2 cellpadding= 2 cellspacing= 0>\n" +

							"<tr><td colspan = 2>\n" +

                            "<img  align =center src=\"cid:hoursOfAvailability\" alt = Scripted By: Nanda Kumar(AB54030) title = Scripted By: Nanda Kumar(AB54030) border =2 bordercolor = #006600>\n"+

							"<tr><b><td colspan = 2 align= left valign=middle style=background-color:#195C19;color:#FFFFFF;><font face= verdana size =1><center>Scripted By:EON_TEST (Saurabh Kumar(SXKUM64) & Nanda Kumar(AB54030))</center></face></td></b></tr>\n"+

							"</table>\n" +                            
                            
                            "<br>\n"+

                            "<br>\n"+                                

                            "<pr>Host System Name & IP Addresss on which Sanity script ran are\n"+ hostname +"<text>, </text>\n" + hostIPAddress+"</p>\n"+

                            "<br>\n"+
                            
							"<pr>*** Implementation of CTL-STAF framework for EON-GC project is done by:<i><b>EON_Test (Nanda Kumar & Saurabh Kumar)</b></i> ***</p>\n"+
							"<pr>***<i><b>Chinni, Praveen K: PROJECT LEAD - TESTING; Jain, Vivek: Offshore, TECHNICAL MANAGER - TESTING; Lemle, Keith: Onshore, MGR IT TESTING</b></i> ***</p>\n"+
                            
							"<br>\n"+

                            "<pr>Note*: This mail is a result of automatically triggered sanity build from corporate jenkins and a seperate cucumber-jvm report - configured in corporate jenkins goes to only few recipients.</p>\n"+

                            "<br>\n"+

                            "<br>\n"+

                            "<br>\n"+

							"<br>\n"+

                            "<pr>Regards,</pr>\n"+

                            "<br>\n"+

                            "<pr>Nanda Kumar</pr>\n"+

                            "</body>\n"+

                            "</html>";   


			msgBodyPart.setContent(htmlText, "text/html");
			multipart.addBodyPart(msgBodyPart);
			
			Map<String, String> mapinlineImages = new HashMap<String, String>();
			mapinlineImages.put("hoursOfAvailability", System.getProperty("user.dir")+"\\target\\hoursOfAvailability.jpg");
		 	     
	        if (mapinlineImages != null && mapinlineImages.size() > 0) {
	            Set<String> setImageID = mapinlineImages.keySet();
	             
	            for (String contentId : setImageID) {
	                MimeBodyPart imagePart = new MimeBodyPart();
	                imagePart.setHeader("Content-ID", "<" + contentId + ">");
	                imagePart.setDisposition(MimeBodyPart.INLINE);
	                 
	                String imageFilePath = mapinlineImages.get(contentId);
	                try {
	                    imagePart.attachFile(imageFilePath);
	                } catch (IOException ex) {
	                    ex.printStackTrace();
	                }
	 
	                multipart.addBodyPart(imagePart);
	            }
	        }
	        
			msg.setContent(multipart);
			Transport.send(msg);

			System.out.println("Sent message successfully....");

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}

	}	
	
	}


	public void validate_ITS_TELECOMUNICAÇÕES_LTDA_removed_from_localLoop(String SubProfile) {
		ItemTAB = getDriver().getWindowHandle();
		waitABit(1000);
		EonDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonDetailsPage.ddl_SubProfile.selectByVisibleText(SubProfile);
		assertTrue(EonDetailsPage.ddl_SubProfile.getSelectedVisibleTextValue().contains(SubProfile));
		EonDetailsPage.ddl_AccessCKT_A.selectByVisibleText("N");
		EonDetailsPage.ddl_AccessCKT_Z.selectByVisibleText("N");
		
		// Local Loop Vendor A: validation 
		System.out.println("**********Local Loop A side validation STARTS***********");
		Select s=new Select(getDriver().findElement(By.xpath("//select[@id='VendorInterface.vendorName.A']")));
		List<WebElement> localloopA=s.getOptions();
		System.out.println("Number of available values in local loop A ddl: "+localloopA.size());
		for(int i=0;i<localloopA.size();i++) {
			System.out.println(localloopA.get(i).getText());
			assertNotEquals("ITS TELECOMUNICAÇÕES LTDA", "ITS TELECOMUNICAÇÕES LTDA", localloopA.get(i).getText());
		}
		System.out.println("ITS TELECOMUNICAÇÕES LTDA is not available in Local loop A side");
		System.out.println("**********Local Loop A side validation ENDS***********");
		
		// Local Loop Vendor Z: validation
		System.out.println("**********Local Loop Z side validation STARTS***********");
		Select s1 = new Select(getDriver().findElement(By.xpath("//select[@id='VendorInterface.vendorName.Z']")));
		List<WebElement> localloopZ = s1.getOptions();
		System.out.println("Number of available values in local loop Z ddl: " + localloopZ.size());
		for (int i = 0; i < localloopZ.size(); i++) {
			//System.out.println(localloopZ.get(i).getText());
			assertNotEquals("ITS TELECOMUNICAÇÕES LTDA", "ITS TELECOMUNICAÇÕES LTDA", localloopZ.get(i).getText());
		}
		System.out.println("ITS TELECOMUNICAÇÕES LTDA is not available in Local loop Z side");
		System.out.println("**********Local Loop Z side validation ENDS***********");

	}


	public void configuartion_before_save_IPGateway() {
		ItemTAB = getDriver().getWindowHandle();
		waitABit(1000);
		EonDIAItemDetailsPage.Windowhandle("Item");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		EonDetailsPage.btn_wantdate.click();
		EonDetailsPage.lnk_wantdateSelect.click();
		EonDetailsPage.btn_Intervaldate.click();
		EonDetailsPage.lnk_IntervaldateSelect.click();
		EonDetailsPage.btn_Save.click();
		waitABit(10000);
	}


	public void select_NSDLocation_and_Device_Values(String nsdlocation, String device) {
		waitABit(10000);
		EonDetailsPage.ddl_NSDLocation.selectByVisibleText(nsdlocation);
		assertEquals("NSD Location ", EonDetailsPage.ddl_NSDLocation.getSelectedVisibleTextValue(), nsdlocation);
		waitABit(10000);
		EonDetailsPage.ddl_Device.selectByVisibleText(device);
		assertEquals("Device ", EonDetailsPage.ddl_Device.getSelectedVisibleTextValue(), device);
		System.out.println("NSD location value is: "+EonDetailsPage.ddl_NSDLocation.getSelectedVisibleTextValue()+" and corresponding Device value is: "+EonDetailsPage.ddl_Device.getSelectedVisibleTextValue());
	}


	public void Active_Directory_Domain_Password_Reset(String link) {
		if(link.equals("Active Directory Domain Password Reset_link1")) {
			EonLoginPage.lnk_PWDReset.click();
		}else if(link.equals("Active Directory Domain Password Reset_link2")) {
			EonLoginPage.lnk_PWDReset1.click();
		}
	}


	public void password_reset_page(String pwdurl) {
		String currentURL=getDriver().getCurrentUrl();
		assertEquals("Asserting PWD URL", currentURL, pwdurl);
		System.out.println("URL matched "+currentURL);
	}


	public void validate_user_in_PWD_Reset_page() {
		EonLoginPage.lbl_AMStext.getText().equals("AMS domain password reset");
		
	}


	public void select_the_configuaration_and_validate_Cloud_connect_Values_IPVRP() throws InterruptedException {
		waitABit(5000);
		IntDataContainer dat = get_data_for_page(EonIPVRPItemDetailsPage).getContainer("IPVRP");
		fillFields(EonIPVRPItemDetailsPage, dat.getMandatoryFieldsFromAllContainers());
		System.out.println("IP VRP selected few conifg");
		waitABit(3000);
		EonDetailsPage.tbx_AccessCircuitID.sendKeys("2006792188");
		//EonDetailsPage.tbx_AccessCircuitID.sendKeys(AccessCircuitID);
		EonDetailsPage.btn_Save.click();
		Thread.sleep(7000);
		IntDataContainer data = get_data_for_page(EonIPVRPItemDetailsPage).getContainer("IPVRPAfterSaveCloudConnect");
		fillFields(EonIPVRPItemDetailsPage, data.getMandatoryFieldsFromAllContainers());
		Thread.sleep(7000);
		System.out.println(EonIPVRPItemDetailsPage.cbx_cloudConnect.isEnabled());
		JavascriptExecutor executor= (JavascriptExecutor) getDriver();
        executor.executeScript("arguments[0].scrollIntoView(true);", EonIPVRPItemDetailsPage.cbx_cloudConnect);
        waitABit(3000);
        try {
			EonIPVRPItemDetailsPage.cbx_cloudConnect.click();
		} catch (Exception e1) {
			e1.printStackTrace();
			executor.executeScript("arguments[0].click;",EonIPVRPItemDetailsPage.cbx_cloudConnect);
		}
		Thread.sleep(5000);
		String CloudConnectProduct []= {"AWS","BJN","Google","HP","IBM Cloud","IBM CMS","MS Azure Priv","MS Peering","MS GOV Azure Priv","MS GOV MS Peering","Oracle"};
		
		try {
			System.out.println(EonIPVRPItemDetailsPage.ddl_cloudConnectProduct.isEnabled());
		} catch (Exception e) {
			e.printStackTrace();
		}
		for(String CCP:CloudConnectProduct) {
		Thread.sleep(2000);
		EonIPVRPItemDetailsPage.ddl_cloudConnectProduct.selectByVisibleText(CCP);
		System.out.println("Selected Cloud connect product: "+ CCP);
		assertEquals("Cloud connect Product ddl validation: ", CCP, EonIPVRPItemDetailsPage.ddl_cloudConnectProduct.getSelectedVisibleTextValue());
		}
		EonIPVRPItemDetailsPage.btn_mainsavebutton.click();
	}


	public void complete_only_checkOrder_task_and_verify_AutoCCDCalculator() throws InterruptedException {
		System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		EonDetailsPage.btn_StartInHistory.click();
		waitABit(3000);
		EonDetailsPage.btn_RefreshInHistory.click();
		waitABit(3000);
		EonDetailsPage.getDriver().findElement(By.linkText("Check Order")).click();
		waitABit(6000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		Thread.sleep(100000);
		EonDetailsPage.btn_CheckorderTaskComplete.click();
		System.out.println("completed check order task manually");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().alert().accept();
		waitABit(6000);
    	System.out.println("**********************REMARKS TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_RemarksTAB.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(5000);
		if(EonDetailsPage.btn_showSystemRemarks.isEnabled()) {
		EonDetailsPage.btn_showSystemRemarks.click();
		}else {
			((JavascriptExecutor)getDriver()).executeScript("arguments[0].click;", EonDetailsPage.btn_showSystemRemarks);
		}
	    assertEquals("Auto CCD calculator check:", "Auto update:  CCD has been updated based on the response received from autoccdset calculator", EonDetailsPage.lbl_CCDtext.getText());
	    System.out.println("Assertion passed for Auot CCD");
    }
    
	public void select_the_configuaration_template_for_EtherExtend_Invalid_circuitSpeed() throws InterruptedException {
		IntDataContainer data = get_data_for_page(EonItemDetailsPage).getContainer("EtherExtendItemDetailsPage");
		fillFields(EonItemDetailsPage, data.getMandatoryFieldsFromAllContainers());
		
		getDriver().switchTo().window("premAdd");
	    System.out.println("Switched to child window");
	    getDriver().manage().window().maximize();
		EonItemDetailsPage.getDriver().switchTo().defaultContent();
		EonItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		EonItemDetailsPage.ddl_editAll.selectByVisibleText("N");
		EonItemDetailsPage.tbx_SiteName.sendKeys("Test Automation location");
		EonItemDetailsPage.ddl_Addresscountry.selectByVisibleText("Ireland");
		EonItemDetailsPage.tbx_SitephoneNumber.sendKeys("4029987779");
		EonItemDetailsPage.btn_SaveConfig.click();		
		waitABit(5000);
		EonItemDetailsPage.btn_close.click();
		System.out.println("closed the address window");
		EonDIAItemDetailsPage.Windowhandle("Item");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDIAItemDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDIAItemDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
        EonItemDetailsPage.btn_mainsavebutton.click();

		}


	public void validate_error_message_in_HistoryTAB() throws InterruptedException {
		System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		assertFalse("Asserting Start button Disable:", EonDetailsPage.btn_StartInHistory.isEnabled());
		System.out.println("START button is DISABLED");
		assertEquals("Asserting error message: ", "Validation Error: Expecting circuit speed value with unit \"M\" but received \"\" on its detail page.", EonDetailsPage.lbl_CKTErrorMessage.getText());
        System.out.println("Circuit speed validation error message is shown ");
        //Switching back to Details page and selecting the valid circuit speed
        EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_DetailsTAB.click();
        waitABit(2000);
        EonDetailsPage.getDriver().switchTo().defaultContent();
        EonDetailsPage.getDriver().switchTo().frame("workspacePane");
        EonDetailsPage.getDriver().switchTo().frame("entry_pane");
        waitABit(2000);
        EonItemDetailsPage.tbx_bandwidthCode.clear();
        EonItemDetailsPage.tbx_bandwidthCode.sendKeys("10M");//selecting again valid BW
        waitABit(2000);
        ((JavascriptExecutor)getDriver()).executeScript("arguments[0].scrollIntoView(true);",EonItemDetailsPage.btn_mainsavebutton);
        waitABit(6000);
        ((JavascriptExecutor)getDriver()).executeScript("arguments[0].click();",EonItemDetailsPage.btn_mainsavebutton);
        System.out.println("saved the config with 10M");
        waitABit(5000);
        System.out.println("Saved the config without losing the existing values");
        //checking if start button is enabled to start work flow 
        System.out.println("**********************HISTORY TAB****************");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_HistoryTAB.click();
		System.out.println("Switched to TABS pane and clicked on HISTORY TAB");
		waitABit(3000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		assertTrue("Asserting Start button Disable:", EonDetailsPage.btn_StartInHistory.isEnabled());
		System.out.println("START button is ENABLED");

	}

	public void goto_utility_page() {
		waitABit(2000);
		EonDetailsPage.Windowhandle("Home");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("nav_frame");
		EonDetailsPage.lbl_Admin.click();
		EonDetailsPage.Windowhandle("Admin");
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		System.out.println("Switched to TAB pane");
		EonDetailsPage.lbl_Utilities.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
	}

	public void verify_utility_list_added_to_BulkUploadOrder() {
		EonDetailsPage.lnk_BulkUploadOrders.click();
		assertEquals("Asserting Utility List ", "Utility List", EonDetailsPage.lnk_UtilityList.getText());
		EonDetailsPage.lnk_UtilityList.click();
		assertEquals("Asserting on click on Utility List control retuned to Utilities TAB ", "Bulk Upload Orders",EonDetailsPage.lnk_BulkUploadOrders.getText());
	}
	
	public void verify_Bulk_record_update_utilities(String utilityList, String popupmsg) {
		//String BulkRecordUpdates[] = {"Bulk Upload Orders","Bulk Update Item and CKT status","Bulk Tasks","Complete Bulk Workflow tasks","Bulk MOD Orders - Billing Only",
			//	                       "Bulk Update CKT status","Cleanup Vendor Circuit ID","Update Account Information","Bulk Update EON FRO IDs"};
		//for(String BRU:BulkRecordUpdates) {
			getDriver().findElement(By.linkText(utilityList)).click();
			EonDetailsPage.btn_LoadOrder.click();
			EonDetailsPage.getAlert().getText().equals(popupmsg);
			EonDetailsPage.getAlert().accept();
			System.out.println("User does not upload spreadsheet and clicked on - "+EonDetailsPage.btn_LoadOrder.getAttribute("value") +"- and the error message is -"+popupmsg +"- displayed");
			EonDetailsPage.lnk_UtilityList.click();
		//}
	}


	public void verify_utility_is_added_to_LegacyNon_usable_Utilities() {
		
		String Legacy_NonUsable_utilities []= {"Locked Users Report","Fibernet Migration","Metasolv Migration"};
		for(String LNUU:Legacy_NonUsable_utilities) {
			getDriver().findElement(By.linkText(LNUU)).click();
			assertEquals("Asserting Utility List ", "Utility List", EonDetailsPage.lnk_UtilityList.getText());
			EonDetailsPage.lnk_UtilityList.click();
			assertEquals("Asserting on click on Utility List control retuned to Utilities TAB ",LNUU,getDriver().findElement(By.linkText(LNUU)).getText());
			System.out.println("Verification completed for the utility: "+LNUU);
		}
	}


	public void CFA_TAB_select_FOC_DLR_Loop_Date() throws ParseException {
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		EonDetailsPage.lbl_CFATAB.click();
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Work Space pane");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		System.out.println("Switched to Entry_pane");
		EonDetailsPage.tbx_FOCReceivedDateA.sendKeys(date1);
		EonDetailsPage.tbx_FOCReceivedDateZ.sendKeys(date1);
		EonDetailsPage.tbx_DLRReceivedDateA.sendKeys(date1);
		EonDetailsPage.tbx_DLRReceivedDateZ.sendKeys(date1);
		EonDetailsPage.tbx_LoopAcceptDateA.sendKeys(date1);
		EonDetailsPage.tbx_LoopAcceptDateZ.sendKeys(date1);
		EonDetailsPage.btn_SaveConfig.click();
		
		datesonUI= new HashMap<String,String>();
		datesonUI.put("focReceivedDate_Aside", EonDetailsPage.Dateconverter(EonDetailsPage.tbx_FOCReceivedDateA.getAttribute("value")));
		datesonUI.put("dlrReceivedDate_Aside", EonDetailsPage.Dateconverter(EonDetailsPage.tbx_DLRReceivedDateA.getAttribute("value")));
		datesonUI.put("loopAcceptDate_Aside",  EonDetailsPage.Dateconverter(EonDetailsPage.tbx_LoopAcceptDateA.getAttribute("value")));
		datesonUI.put("focReceivedDate_Zside", EonDetailsPage.Dateconverter(EonDetailsPage.tbx_FOCReceivedDateZ.getAttribute("value")));
		datesonUI.put("dlrReceivedDate_Zside", EonDetailsPage.Dateconverter(EonDetailsPage.tbx_DLRReceivedDateZ.getAttribute("value")));
		datesonUI.put("loopAcceptDate_Zside",  EonDetailsPage.Dateconverter(EonDetailsPage.tbx_LoopAcceptDateZ.getAttribute("value")));
		
		/* Display content using Iterator
	      Set set = datesonUI.entrySet();
	      Iterator iterator = set.iterator();
	      while(iterator.hasNext()) {
	         Map.Entry mentry = (Map.Entry)iterator.next();
	         System.out.print("key is: "+ mentry.getKey() + " & Value is: ");
	         System.out.println(mentry.getValue());
	      }*/
		System.out.println("Dates from UI: "+datesonUI);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("header_pane");
		System.out.println("Switched to header_pane");
		Order_Item = EonDetailsPage.lbl_OrderNumber.getText() + EonDetailsPage.lbl_LineItem.getText();
		System.out.println("######################### ORDER DETAILS ###################################");
		System.out.println("#                                                                         #");
		System.out.println("# Product      : " + productSelected);
		System.out.println("# Order_Item        : " + Order_Item);
		System.out.println("#                                                                         #");
		System.out.println("####################### ***SCRIPTED BY: EON_TEST (Nanda Kumar)*** #########");
		String s[]=Order_Item.split(" ");
		OrderItemForRest=s[0]+s[1]+s[2];
		
	}


	public void validate_REST_response() {

		Environment envi=currentEnvironment;
		String currentTestEnv=currentEnvironment.toString();
		System.out.println(currentTestEnv);
        if(currentTestEnv.equals("End to End")){
        	currentTestEnv="qa4";
        }else if(currentTestEnv.equals("Test Env 3")) {
        	currentTestEnv="qa3";
        }
		String GetURL="http://"+currentTestEnv+"-eon.level3.com/eon/rest/services/autoorder/getDetailsbyOrderItem?orderItem="+OrderItemForRest;
		System.out.println("GET URL: "+GetURL);
		HashMap<String,String> datesfromREST=RestAssured.given().contentType(ContentType.JSON)
		.get(GetURL).then().extract().path("item.dates");
		System.out.println("****************************focReceivedDate,loopAcceptDate&dlrReceivedDate************************");
		System.out.println("dates from REST response: "+datesfromREST);
		System.out.println("dates from applicaton: "+datesonUI);
		assertEquals("Asserting UI date vs REST date",datesonUI, datesfromREST);
		System.out.println("**************************************************************************************************");
		System.out.println("Assertion passed");
		
		
	}


	public void call_RESTAPI_PUT_to_update_TRTSDate() throws ParseException {
		
		String details=captureOrderDetailsforRestService();	
		String Order_Item[]=details.split("/");
		
		TRTSDate=EonDetailsPage.DateforTRTS();
		@SuppressWarnings("unused")
		Environment envi=currentEnvironment;
		String currentTestEnv=currentEnvironment.toString();
		System.out.println(currentTestEnv);
        if(currentTestEnv.equals("End to End")){
        	currentTestEnv="qa4";
        }else if(currentTestEnv.equals("Test Env 3")) {
        	currentTestEnv="qa3";
        }
		String PUT_URL="http://"+currentTestEnv+"-eon.level3.com/eon/rest/services/Application/v1/Eon/orderUpdate/updateCCD";
		System.out.println("PUT URL: "+PUT_URL);
		
		String restBodyXML="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n" + 
				"<updateCCD>\r\n" + 
				"<orderNo>"+Order_Item[0]+"</orderNo>\r\n" + 
				"<itemNo>"+Order_Item[1]+"</itemNo>\r\n" + 
				"<userId>U1160925</userId>\r\n" + 
				"<ccdDate>"+TRTSDate[0]+" 20:07:76</ccdDate>\r\n" + 
				"</updateCCD>";
		System.out.println("restBodyXML: "+restBodyXML);
		//Put call
		RestAssured.given().contentType(ContentType.XML).body(restBodyXML).put(PUT_URL)
		.then().statusCode(200);
		System.out.println("REST Update successful");
		
	}

  public String captureOrderDetailsforRestService() {
	    EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("header_pane");
		System.out.println("Switched to header_pane");
		Order_Item = EonDetailsPage.lbl_OrderNumber.getText() + EonDetailsPage.lbl_LineItem.getText();
		System.out.println("######################### ORDER DETAILS ###################################");
		System.out.println("#                                                                         #");
		System.out.println("# Product      : " + productSelected);
		System.out.println("# Order_Item        : " + Order_Item);
		System.out.println("#                                                                         #");
		System.out.println("####################### ***SCRIPTED BY: EON_TEST (Nanda Kumar)*** #########");
		String s[]=Order_Item.split(" ");
		return OrderItemForRest=s[0]+s[1]+s[2];
  }


	public void Validate_TRTS_date_updated_by_REST_API() {
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		waitABit(2000);
		EonDetailsPage.lbl_DetailsTAB.click();
		waitABit(4000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		String ItemTRTStext;
		try {
			ItemTRTStext=EonDetailsPage.lbl_TRSDateText.getText();
		} catch (Exception e) {
			//e.printStackTrace();
			ItemTRTStext=EonDetailsPage.lbl_TRSDateTextUNI.getText();
		}
		assertTrue("Validate TRTS date is updated by REST or not ",TRTSDate[1].equals(ItemTRTStext));
		System.out.println("***Assertion Passed***");
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("tab_pane");
		waitABit(2000);
		EonDetailsPage.lbl_RemarksTAB.click();
		waitABit(4000);
		EonDetailsPage.getDriver().switchTo().defaultContent();
		EonDetailsPage.getDriver().switchTo().frame("workspacePane");
		System.out.println("Switched to Wokspacepane");
		waitABit(2000);
		waitABit(2000);
		EonDetailsPage.getDriver().switchTo().frame("entry_pane");
		waitABit(2000);
		assertTrue("Validating TRTS Date in REMARKS TAB: ",EonDetailsPage.lbl_TRTSdateRemarksTab.getText().contains("Operational ready updated:"));
		String TRTStext=TRTSDate[1]+" -  CCD date updated";
		System.out.println("Partial original Text "+ TRTStext);
		System.out.println("Text from UI "+ EonDetailsPage.lbl_TRTSdateRemarksTab.getText());
		assertTrue(EonDetailsPage.lbl_TRTSdateRemarksTab.getText().contains(TRTSDate[1]+" -  CCD date updated"));
	}
	
 
}