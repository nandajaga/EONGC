/**
 * 
 */
package com.ctl.it.qa.eon.tools.pages.common;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ctl.it.qa.eon.tools.pages.EonPage;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

/**
 * @author AB54030
 *
 */
public class EonDetailsPage extends EonPage {

	@FindBy(id = "main:accountNumber")
	public WebElementFacade tbx_accountNumber;
	
	@FindBy(xpath = "//td[@id='tab3_ins3']")
	public WebElementFacade lbl_ordersTAB;
	
	@FindBy(id="toolbar_new_image")
	public WebElementFacade btn_NEW;
	
	@FindBy(id="main:salesRegion")
	public WebElementFacade ddl_salesRegion;
	
	@FindBy(id="main:orderType")
	public WebElementFacade ddl_orderType;
	
	@FindBy(id="main:orderNumberSuppliedFlag")
	public WebElementFacade ddl_CONS;
	
	@FindBy(id="main:salesType")
	public WebElementFacade ddl_salesType;
	
	@FindBy(id="main:salesVertical")
	public WebElementFacade ddl_salesvertical;
	
	@FindBy(id="main:billingSystem")
	public WebElementFacade ddl_BillingSystem;
	
	@FindBy(id="main:billingEntity")
	public WebElementFacade ddl_SalesBillingEntity;
	
	@FindBy(id="main:drivingSystem")
	public WebElementFacade ddl_Drivingsystem;
	
	@FindBy(id="main:designAuthority")
	public WebElementFacade ddl_DrivingAuthority;
	
	@FindBy(id="main:altContactSuppliedFlag")
	public WebElementFacade ddl_AlternateContact;
	
	@FindBy(id="main:j_id256")
	public WebElementFacade btn_AddContact;
	
	@FindBy(id="contactModal:orderContactType")
	public WebElementFacade ddl_contactType;
	
	@FindBy(id="contactModal:contactFirstName")
	public WebElementFacade tbx_contactFirstName;
	
	@FindBy(id="contactModal:contactLastName")
	public WebElementFacade tbx_contactLastName;
	
	@FindBy(id="contactModal:contactPhoneNumber1")
	public WebElementFacade tbx_contactphoneNumber;
	
	@FindBy(id="contactModal:contactEmail")
	public WebElementFacade tbx_contactemail;
	
	@FindBy(id="contactModal:saveActionButton")
	public WebElementFacade btn_contactTypesave;
	
	@FindBy(id="main:gcodContactName")
	public WebElementFacade tbx_gcodContactName;
	
	@FindBy(id="main:supportName")
	public WebElementFacade tbx_supportName;
	
	@FindBy(id="main:repName")
	public WebElementFacade tbx_repName;
	
	@FindBy(id="main:savebutton")
	public WebElementFacade btn_mainsavebutton;
	
	@FindBy(id="main:receivedDateInputDate")
	public WebElementFacade tbx_receivedDate;
	
	@FindBy(id="main:signedDateInputDate")
	public WebElementFacade tbx_signedDate;
		
	@FindBy(css="#tab2_ins3")
	public WebElementFacade lbl_ItemsTab;
	
	@FindBy(name="newItemType")
	public WebElementFacade ddl_Product;
	
	@FindBy(name="newItemAction")
	public WebElementFacade ddl_action;
	
	@FindBy(css="#toolbar_add_image")
	public WebElementFacade btn_productAdd;
	
	@FindBy(id="SonetItem.fullSubProfileCode")
	public WebElementFacade ddl_SubProfile;
	
	@FindBy(id="main:subProfile")
	public WebElementFacade ddl_SubProfile1;
	

	@FindBy(css="#tab3_ins3")
	public WebElementFacade lbl_HistoryTAB;
	
	@FindBy(css="#tab2_ins3")
	public WebElementFacade lbl_RemarksTAB;
	
	@FindBy(xpath="//input[@value='Show System Remarks']")
	public WebElementFacade btn_showSystemRemarks;
	
	@FindBy(xpath="//*[text()='Auto update:  CCD has been updated based on the response received from autoccdset calculator']")
	public WebElementFacade lbl_CCDtext;
	
	@FindBy(css="#toolbar_complete_image")
	public WebElementFacade btn_CheckorderTaskComplete;
	
	@FindBy(css="#tab13_ins3")
	public WebElementFacade lbl_ContactsTAB;
	
	@FindBy(css="#toolbar_new_image")
	public WebElementFacade btn_new;
	
	@FindBy(id="Contact.hoursOfAvailability")
	public WebElementFacade tbx_hoursOfAvailability;
	
	@FindBy(css="#notifyCode")
	public WebElementFacade ddl_notification;
	
	@FindBy(id="main:completeOnClick")
	public WebElementFacade cbx_CompleteOnClickAdmin;
	
	@FindBy(name="main:j_id89")
	public WebElementFacade btn_StartInHistory;
	
	@FindBy(name="main:j_id92")
	public WebElementFacade btn_RefreshInHistory;
	
	@FindBy(name="main:j_id92")
	public WebElementFacade btn_Refreshbtn;
	
	@FindBy(xpath="//table[@id='cpi_table']//span[2]/descendant::a")
	public WebElementFacade lbl_OrderNumber;
	
	@FindBy(xpath="(//span[@class='headervalue'])[1]")
	public WebElementFacade lbl_OrderNumber1;
	
	@FindBy(xpath="//table[@id='cpi_table']/tbody/tr[2]/td[1]/span[3]")
	public WebElementFacade lbl_LineItem;
	
	@FindBy(xpath="//table[@id='cpi_table']/tbody/tr[3]/td[1]/span[3]/a")
	public WebElementFacade lbl_CircuitID;
	
	@FindBy(xpath="//table[@id='cpi_table']/tbody/tr[1]/td[3]/span[2]")
	public WebElementFacade lbl_Status;
	
	@FindBy(id="SonetItem.wantDate")
	public WebElementFacade tbx_WantDate;
	
	@FindBy(id="LoopDates.standardIntervalDate.P")
	public WebElementFacade tbx_IntervalDate;
	
	@FindBy(id="SonetItem.circuitCapacity")
	public WebElementFacade ddl_capacity ;
	
	@FindBy(id="main:circuitCapacity")
	public WebElementFacade ddl_capacityDIA ;
	
	@FindBy(id="SonetItem.transportTypeCode")
	public WebElementFacade ddl_SONET;
	
	@FindBy(id="SonetItem.revenuePtlFlag")
	public WebElementFacade ddl_IRU ;
	
	@FindBy(id="SonetItem.internationalServiceRequired")
	public WebElementFacade ddl_CiruitTerm ;
	
	@FindBy(id="SonetItem.hotCutFlag")
	public WebElementFacade ddl_HotCut ;
	
	@FindBy(id="main:hotCutFlag")
	public WebElementFacade ddl_HotCutDIA ;
	
	@FindBy(id="VendorInterface.useExistingAccessFlag.A")
	public WebElementFacade ddl_AccessCKT_A;
	
	@FindBy(id="VendorInterface.useExistingAccessFlag.Z")
	public WebElementFacade ddl_AccessCKT_Z;
	
	@FindBy(id="popExternalId.A")
	public WebElementFacade tbx_popsiteA;
	
	@FindBy(id="popExternalId.Z")
	public WebElementFacade tbx_popsiteZ;
	
	@FindBy(id="VendorInterface.loopRequiredFlag.A")
	public WebElementFacade ddl_LocalLoopRequired_A ;
	
	@FindBy(id="VendorInterface.loopRequiredFlag.Z")
	public WebElementFacade ddl_LocalLoopRequired_Z;
	
	@FindBy(id="VendorInterface.accessTypeCode.A")
	public WebElementFacade ddl_TypeofAccess_A;
	
	@FindBy(id="VendorInterface.accessTypeCode.Z")
	public WebElementFacade ddl_TypeofAccess_Z;
	
	@FindBy(id="VendorInterface.vendorName.A")
	public WebElementFacade ddl_POPLocalLoop_A ;
	
	@FindBy(id="VendorInterface.vendorName.Z")
	public WebElementFacade ddl_POPLocalLoop_Z;
	
	@FindBy(id="VendorInterface.framingSignallingCode.A")
	public WebElementFacade ddl_Framing_A;
	
	@FindBy(id="VendorInterface.framingSignallingCode.Z")
	public WebElementFacade ddl_Framing_Z;
	
	@FindBy(id="VendorInterface.protectionFlag.A")
	public WebElementFacade ddl_Protection_A;
	
	@FindBy(id="VendorInterface.protectionFlag.Z")
	public WebElementFacade ddl_Protection_Z ;
	
	@FindBy(id="externalId.A")
	public WebElementFacade tbx_CustomerPremAddress_A;
	
	@FindBy(id="externalId.Z")
	public WebElementFacade tbx_CustomerPremAddress_Z;
	
	@FindBy(id="toolbar_save_image")
	public WebElementFacade btn_SaveConfig;
	
	@FindBy(name="circuitID")
	public WebElementFacade ddl_circuitID;
	
	@FindBy(xpath="//*[@id='main:wantDateSpan_calendarDiv']//a[contains(@class,'jscalendar-DB-current-day-style jscalendar-DB-selected-day-style')]")
	public WebElementFacade lnk_wantdateSelect ;
	
	@FindBy(xpath="//span[@id='main:wantDate']//input[@type='button']")
	public WebElementFacade btn_wantdate ;
	
	
	@FindBy(xpath="//span[@id='main:intervalDate']//input[@type='button']")
	public WebElementFacade btn_Intervaldate;
	
	@FindBy(xpath="//*[@id='main:intervalDateSpan_calendarDiv']//a[contains(@class,'jscalendar-DB-current-day-style jscalendar-DB-selected-day-style')]")
	public WebElementFacade lnk_IntervaldateSelect;
	
	@FindBy(id="main:accessCircuitA")
	public WebElementFacade tbx_AccessCircuitID;
	
	@FindBy(id="main:savebutton")
	public WebElementFacade btn_Save;
	
	@FindBy(id="main:serviceType")
	public WebElementFacade ddl_ServiceType;
	
	@FindBy(id="main:dirPop")
	public WebElementFacade ddl_DIRPoP;
	
	@FindBy(id="main:portType")
	public WebElementFacade ddl_PortType;
	
	@FindBy(id="main:encapsulation")
	public WebElementFacade ddl_Encapsulation;
	
	@FindBy(id="main:commitBandwidth")
	public WebElementFacade ddl_CommitBandwidth;
	
	@FindBy(id="main:tierSpeed")
	public WebElementFacade ddl_TierSpeed;
	
	@FindBy(id="main:loadBalanceFlag")
	public WebElementFacade ddl_Loadsharing;
	
	@FindBy(id="main:ipv6CustFlag")
	public WebElementFacade ddl_IPv6Customer;
	
	@FindBy(id="main:gatewayLocationStr")
	public WebElementFacade ddl_NSDLocation;
	
	@FindBy(id="main:deviceId")
	public WebElementFacade ddl_Device;
	
	@FindBy(xpath="(//*[text()='Validation Error: Expecting circuit speed value with unit \"M\" but received \"\" on its detail page.'])[1]")
	public WebElementFacade lbl_CKTErrorMessage;
	
	@FindBy(css="#tab0_ins3")
	public WebElementFacade lbl_DetailsTAB;
	
	@FindBy(css="#navbar_admin")
	public WebElementFacade lbl_Admin;
	
	@FindBy(xpath="//td[text()='Utilities']")
	public WebElementFacade lbl_Utilities;
	
	@FindBy(linkText="Bulk Upload Orders")
	public WebElementFacade lnk_BulkUploadOrders;
	
	@FindBy(linkText="Utility List")
	public WebElementFacade lnk_UtilityList;
	
	@FindBy(className="smallButton")
	public WebElementFacade btn_LoadOrder;
	
	@FindBy(xpath="//td[text()='CFA']")
	public WebElementFacade lbl_CFATAB;
	
	@FindBy(xpath="(//input[contains(@id,'focReceivedDate.A')])[1]")
	public WebElementFacade tbx_FOCReceivedDateA;
	
	@FindBy(xpath="(//input[contains(@id,'focReceivedDate.Z')])[1]")
	public WebElementFacade tbx_FOCReceivedDateZ;
	
	@FindBy(xpath="(//input[contains(@id,'dlrReceivedDate.A')])[1]")
	public WebElementFacade tbx_DLRReceivedDateA;
	
	@FindBy(xpath="(//input[contains(@id,'dlrReceivedDate.Z')])[1]")
	public WebElementFacade tbx_DLRReceivedDateZ;
	
	@FindBy(xpath="(//input[contains(@id,'loopAcceptDate.A')])[1]")
	public WebElementFacade tbx_LoopAcceptDateA;
	
	@FindBy(xpath="(//input[contains(@id,'loopAcceptDate.Z')])[1]")
	public WebElementFacade tbx_LoopAcceptDateZ;
	
	@FindBy(xpath="//center//form[@method='post']//table//tr[3]//td[6]//span")
	public WebElementFacade lbl_TRSDateText;
	
	@FindBy(xpath="//pre[contains(text(),'Operational ready updated:')]")
	public WebElementFacade lbl_TRTSdateRemarksTab;
	
	@FindBy(xpath="//label[@id='main:targetReadyLabel']")
	public WebElementFacade lbl_TRSDateTextUNI;
	
	@Override
	public WebElementFacade getUniqueElementInPage() {
		return btn_Save;
	}
	
	//Switch Window with the help of page title
	public void Windowhandle(String title) {
		System.out.println("control in Details page");
	 Set<String> allWindows1= getDriver().getWindowHandles();
		
		if(!allWindows1.isEmpty()) {
			for(String WindowID:allWindows1) {
				try {
				if(getDriver().switchTo().window(WindowID).getTitle().equals(title)) {
						System.out.println("Title is : "+getDriver().getTitle());
						waitABit(3000);
						break; //used to come out of loop and continue execution
					}
				}catch(org.openqa.selenium.NoSuchWindowException e){
						e.printStackTrace();
					}
									
				}
			}

	}
	
	//TO Select the auto listed text in drop down
	public void fn_auotslectText(List<WebElement> autotextddl, String textToSelect) throws InterruptedException {	
		List<WebElement> list= autotextddl;
	    System.out.println("Total auto suggestions==>"+list.size());
	    for(int i=0; i<list.size(); i++){
	    	String autotexts=list.get(i).getText(); // to see the list of auto suggesting words
	    	System.out.println("The auto suggesting words are ==>"+autotexts);
    		Thread.sleep(3000);

	    	if(autotexts.contains(textToSelect)){
	    		list.get(i).click(); // to click on any particular text in auto suggestion
	    		Thread.sleep(3000);
	    		break; // once it found the text comes out of the loop to save time as we found what we need to click
	    	}
	    }	
	}

	public void checkOrderTaskComplete(String[] tasks1) {

		for (final String task : tasks1) {
			try {
				btn_Refreshbtn.click();
				waitABit(3000);
				System.out.println(task);
				(new WebDriverWait(getDriver(), 150)).until(new ExpectedCondition<WebElement>() {
					public WebElement apply(WebDriver d) {
						return d.findElement(By.linkText(task));
					}
				});
				waitABit(2000);
				getDriver().findElement(By.linkText(task)).click();
				System.out.println("clicked on "+task);
				Alert alert = getDriver().switchTo().alert();
				alert.accept();
				waitABit(3000);
				btn_Refreshbtn.click();
				waitABit(3000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		waitABit(2000);
		btn_Refreshbtn.click();
		waitABit(2000);
	}
	
	public void checkOrderTaskCompleteForColoction(String[] tasks1) {
	
		for (final String task : tasks1) {
			try {
				btn_Refreshbtn.click();
				waitABit(3000);
				System.out.println(task);
				(new WebDriverWait(getDriver(), 150)).until(new ExpectedCondition<WebElement>() {
					public WebElement apply(WebDriver d) {
						return d.findElement(By.linkText(task));
					}
				});
				waitABit(2000);
				getDriver().findElement(By.linkText(task)).click();
				System.out.println("clicked on "+task);
				Alert alert = getDriver().switchTo().alert();
				alert.accept();
				waitABit(3000);
				btn_Refreshbtn.click();
				waitABit(3000);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		waitABit(2000);
		btn_Refreshbtn.click();
		waitABit(2000);
	}
	
	public boolean isAlertPresents() {
		try {
		getDriver().switchTo().alert();
		return true;
		}// try
		catch (Exception e) {
		return false;
		}// catch
		}
	
	public String Dateconverter(String Date) throws ParseException {
		Date DF = new Date();
		DateFormat FromDF = new SimpleDateFormat("MM/dd/yy");
		FromDF.setLenient(false); // this is important!
		Date FromDate = FromDF.parse(Date); // "08/01/19"
		String dateStringFrom = new SimpleDateFormat("yyyy-MM-dd").format(FromDate);
		System.out.println(dateStringFrom);
	  return dateStringFrom;
	}
	
	public String[] DateforTRTS() throws ParseException {
		
		//Getting future Date
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 4); // +days
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
		// Now format the date
		String ccd = dateFormat.format(cal.getTime());
        System.out.println("date " +ccd);	// "08/01/19"	
        //Now change the date format to use in REST body  
        DateFormat FromDF = new SimpleDateFormat("MM/dd/yy");
 		FromDF.setLenient(false);
 		Date FromDate = FromDF.parse(ccd); 
 		String RESTDateformat = new SimpleDateFormat("yyyy-MM-dd").format(FromDate);
 		System.out.println("RESTDateformat: "+RESTDateformat); //2019-08-09
 		
        FromDF.setLenient(false);
 		String UIDateformat = new SimpleDateFormat("dd MMM yyyy").format(FromDate);
 		System.out.println("UIDateformat: "+UIDateformat); //09 Aug 2019
 		String TRTSDate[]= {RESTDateformat,UIDateformat};
		return TRTSDate;
		
	}
	
}
