/**
 * 
 */
package com.ctl.it.qa.eon.tools.pages.common;

import java.util.Set;

import com.ctl.it.qa.eon.tools.pages.EonPage;
import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.WebElementFacade;

/**
 * @author AB54030
 *
 */
public class EonDIAItemDetailsPage extends EonPage {

	@FindBy(id = "main:accountNumber")
	public WebElementFacade tbx_accountNumber;
	
	@FindBy(xpath = "//td[@id='tab3_ins3']")
	public WebElementFacade lbl_ordersTAB;
	
	@FindBy(id="toolbar_new_image")
	public WebElementFacade btn_NEW;
	
	@FindBy(id="main:salesRegion")
	public WebElementFacade ddl_salesRegion;
	
	@FindBy(id="main:orderType")
	public WebElementFacade ddl_orderType;
	
	@FindBy(id="main:orderNumberSuppliedFlag")
	public WebElementFacade ddl_CONS;
	
	@FindBy(id="main:salesType")
	public WebElementFacade ddl_salesType;
	
	@FindBy(id="main:salesVertical")
	public WebElementFacade ddl_salesvertical;
	
	@FindBy(id="main:billingSystem")
	public WebElementFacade ddl_BillingSystem;
	
	@FindBy(id="main:billingEntity")
	public WebElementFacade ddl_SalesBillingEntity;
	
	@FindBy(id="main:drivingSystem")
	public WebElementFacade ddl_Drivingsystem;
	
	@FindBy(id="main:designAuthority")
	public WebElementFacade ddl_DrivingAuthority;
	
	@FindBy(id="main:altContactSuppliedFlag")
	public WebElementFacade ddl_AlternateContact;
	
	@FindBy(id="main:j_id256")
	public WebElementFacade btn_AddContact;
	
	@FindBy(id="contactModal:orderContactType")
	public WebElementFacade ddl_contactType;
	
	@FindBy(id="contactModal:contactFirstName")
	public WebElementFacade tbx_contactFirstName;
	
	@FindBy(id="contactModal:contactLastName")
	public WebElementFacade tbx_contactLastName;
	
	@FindBy(id="contactModal:contactPhoneNumber1")
	public WebElementFacade tbx_contactphoneNumber;
	
	@FindBy(id="contactModal:contactEmail")
	public WebElementFacade tbx_contactemail;
	
	@FindBy(id="contactModal:saveActionButton")
	public WebElementFacade btn_contactTypesave;
	
	@FindBy(id="main:gcodContactName")
	public WebElementFacade tbx_gcodContactName;
	
	@FindBy(id="main:supportName")
	public WebElementFacade tbx_supportName;
	
	@FindBy(id="main:repName")
	public WebElementFacade tbx_repName;
	
	@FindBy(id="main:savebutton")
	public WebElementFacade btn_mainsavebutton;
	
	@FindBy(id="main:receivedDateInputDate")
	public WebElementFacade tbx_receivedDate;
	
	@FindBy(id="main:signedDateInputDate")
	public WebElementFacade tbx_signedDate;
		
	@FindBy(css="#tab2_ins3")
	public WebElementFacade lbl_ItemsTab;
	
	@FindBy(name="newItemType")
	public WebElementFacade ddl_Product;
	
	@FindBy(name="newItemAction")
	public WebElementFacade ddl_action;
	
	@FindBy(css="#toolbar_add_image")
	public WebElementFacade btn_productAdd;
	
	@FindBy(id="SonetItem.fullSubProfileCode")
	public WebElementFacade ddl_SubProfile;
	
	//@FindBy(id="main:subProfile")
	@FindBy(xpath="//select[contains(@id,'SubProfile')]")
	public WebElementFacade ddl_SubProfile1;
	
	  @FindBy(id="main:subProfile")
	  public WebElementFacade ddl_SubProfileUNI;
	
	@FindBy(css="#tab3_ins3")
	public WebElementFacade lbl_HistoryTAB;
	
	@FindBy(id="main:completeOnClick")
	public WebElementFacade cbx_CompleteOnClickAdmin;
	
	@FindBy(name="main:j_id89")
	public WebElementFacade btn_StartInHistory;
	
	@FindBy(name="main:j_id92")
	public WebElementFacade btn_RefreshInHistory;
	
	@FindBy(name="main:j_id92")
	public WebElementFacade btn_Refreshbtn;
	
	@FindBy(xpath="//table[@id='cpi_table']//span[2]/descendant::a")
	public WebElementFacade lbl_OrderNumber;
	
	@FindBy(xpath="(//span[@class='headervalue'])[1]")
	public WebElementFacade lbl_OrderNumber1;
	
	@FindBy(xpath="//table[@id='cpi_table']/tbody/tr[2]/td[1]/span[3]")
	public WebElementFacade lbl_LineItem;
	
	@FindBy(xpath="//table[@id='cpi_table']/tbody/tr[3]/td[1]/span[3]/a")
	public WebElementFacade lbl_CircuitID;
	
	@FindBy(xpath="//table[@id='cpi_table']/tbody/tr[1]/td[3]/span[2]")
	public WebElementFacade lbl_Status;
	
	@FindBy(id="SonetItem.wantDate")
	public WebElementFacade tbx_WantDate;
	
	@FindBy(id="LoopDates.standardIntervalDate.P")
	public WebElementFacade tbx_IntervalDate;
	
	@FindBy(id="SonetItem.circuitCapacity")
	public WebElementFacade ddl_capacity ;
	
	@FindBy(id="main:circuitCapacity")
	public WebElementFacade ddl_capacityDIA ;
	
	@FindBy(id="SonetItem.transportTypeCode")
	public WebElementFacade ddl_SONET;
	
	@FindBy(id="SonetItem.revenuePtlFlag")
	public WebElementFacade ddl_IRU ;
	
	@FindBy(id="SonetItem.internationalServiceRequired")
	public WebElementFacade ddl_CiruitTerm ;
	
	@FindBy(id="SonetItem.coloAssistFlag")
	public WebElementFacade ddl_coloAssistFlag;
	
	@FindBy(id="SonetItem.footprintQuantity")
	public WebElementFacade tbx_Colocation_Footprint_Quantity;	
	
	@FindBy(id="SonetItem.hotCutFlag")
	public WebElementFacade ddl_HotCut ;
	
	@FindBy(id="main:hotCutFlag")
	public WebElementFacade ddl_HotCutDIA ;
	
	@FindBy(id="VendorInterface.useExistingAccessFlag.A")
	public WebElementFacade ddl_AccessCKT_A;
	
	@FindBy(id="VendorInterface.useExistingAccessFlag.Z")
	public WebElementFacade ddl_AccessCKT_Z;
	
	@FindBy(id="popExternalId.A")
	public WebElementFacade tbx_popsiteA;
	
	@FindBy(id="popExternalId.Z")
	public WebElementFacade tbx_popsiteZ;
	
	@FindBy(id="VendorInterface.loopRequiredFlag.A")
	public WebElementFacade ddl_LocalLoopRequired_A ;
	
	@FindBy(id="VendorInterface.loopRequiredFlag.Z")
	public WebElementFacade ddl_LocalLoopRequired_Z;
	
	@FindBy(id="VendorInterface.accessTypeCode.A")
	public WebElementFacade ddl_TypeofAccess_A;
	
	@FindBy(id="VendorInterface.accessTypeCode.Z")
	public WebElementFacade ddl_TypeofAccess_Z;
	
	@FindBy(id="VendorInterface.vendorName.A")
	public WebElementFacade ddl_POPLocalLoop_A ;
	
	@FindBy(id="VendorInterface.vendorName.Z")
	public WebElementFacade ddl_POPLocalLoop_Z;
	
	@FindBy(id="VendorInterface.framingSignallingCode.A")
	public WebElementFacade ddl_Framing_A;
	
	@FindBy(id="VendorInterface.framingSignallingCode.Z")
	public WebElementFacade ddl_Framing_Z;
	
	@FindBy(id="VendorInterface.protectionFlag.A")
	public WebElementFacade ddl_Protection_A;
	
	@FindBy(id="VendorInterface.protectionFlag.Z")
	public WebElementFacade ddl_Protection_Z ;
	
	@FindBy(id="externalId.A")
	public WebElementFacade tbx_CustomerPremAddress_A;
	
	@FindBy(id="externalId.Z")
	public WebElementFacade tbx_CustomerPremAddress_Z;
	
	@FindBy(id="toolbar_save_image")
	public WebElementFacade btn_SaveConfig;
	
	@FindBy(name="circuitID")
	public WebElementFacade ddl_circuitID;
	
	@FindBy(xpath="//*[@id='main:wantDateSpan_calendarDiv']//a[contains(@class,'jscalendar-DB-current-day-style jscalendar-DB-selected-day-style')]")
	public WebElementFacade lnk_wantdateSelect ;
	
	@FindBy(xpath="//span[@id='main:wantDate']//input[@type='button']")
	public WebElementFacade btn_wantdate ;
	
	
	@FindBy(xpath="//span[@id='main:intervalDate']//input[@type='button']")
	public WebElementFacade btn_Intervaldate;
	
	@FindBy(xpath="//*[@id='main:intervalDateSpan_calendarDiv']//a[contains(@class,'jscalendar-DB-current-day-style jscalendar-DB-selected-day-style')]")
	public WebElementFacade lnk_IntervaldateSelect;
	
	@FindBy(id="main:accessCircuitA")
	public WebElementFacade tbx_AccessCircuitID;
	
	@FindBy(id="main:savebutton")
	public WebElementFacade btn_Save;
	
	@FindBy(xpath="//*[@id='toolbar_save_image']")
	public WebElementFacade btn_Save_item_details;
		
	@FindBy(id="main:serviceType")
	public WebElementFacade ddl_ServiceType;
	
	@FindBy(id="main:dirPop")
	public WebElementFacade ddl_DIRPoP;
	
	@FindBy(id="main:portType")
	public WebElementFacade ddl_PortType;
	
	@FindBy(id="main:encapsulation")
	public WebElementFacade ddl_Encapsulation;
	
	@FindBy(id="main:commitBandwidth")
	public WebElementFacade ddl_CommitBandwidth;
	
	@FindBy(id="main:tierSpeed")
	public WebElementFacade ddl_TierSpeed;
	
	@FindBy(id="main:loadBalanceFlag")
	public WebElementFacade ddl_Loadsharing;
	
	@FindBy(id="main:ipv6CustFlag")
	public WebElementFacade ddl_IPv6Customer;
	
	//Switch Window with the help of page title
	public void Windowhandle(String title) {
	System.out.println("control in Details page");
	 Set<String> allWindows1= getDriver().getWindowHandles();
		
		if(!allWindows1.isEmpty()) {
			for(String WindowID:allWindows1) {
				try {
				if(getDriver().switchTo().window(WindowID).getTitle().equals(title)) {
						System.out.println("Title is : "+getDriver().getTitle());
						waitABit(3000);
						break; //used to come out of loop and continue execution
					}
				}catch(org.openqa.selenium.NoSuchWindowException e){
						e.printStackTrace();
					}
									
				}
			}

	}
	
	
	
	@Override
	public WebElementFacade getUniqueElementInPage() {
		return btn_Save;
	}
	
	
	
}
